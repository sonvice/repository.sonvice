# -*- coding: utf-8 -*-
"""
TorrentResolver — Resolve streams via Elementum, Quasar, or Real-Debrid.
v2: Added RD support. RD cached streams become direct HTTP = instant play.
"""
import re
from urllib.parse import quote
import urllib.request
import urllib.response
import json

from resources.lib.config import Config
from resources.lib.debrid import RealDebrid
from resources.lib.spanish import detect_spanish, get_spanish_label, get_spanish_boost
from resources.lib.logger import log
from resources.lib import ui
import xbmc
import xbmcgui

QUALITY_PATTERNS = {
    "4K":    re.compile(r"(2160p|4k|uhd)", re.IGNORECASE),
    "1080p": re.compile(r"1080p", re.IGNORECASE),
    "720p":  re.compile(r"720p", re.IGNORECASE),
    "480p":  re.compile(r"(480p|sd)", re.IGNORECASE),
}

TRACKERS = [
    # Tier-1 High Availability Open Trackers (Fast UDP & HTTP fallback)
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://explodie.org:6969/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "http://tracker.opentrackr.org:1337/announce",
    "https://tracker.tamersunion.org:443/announce",
]


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.response.addinfourl(fp, headers, headers.get("Location", ""), code)
        return infourl
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302


class TorrentResolver:
    def __init__(self):
        self.engine = Config.torrent_engine()
        self.rd = RealDebrid()

    def pause_elementum_torrents(self, exclude_hash=None):
        """
        Pause competing torrents in Elementum to prevent bandwidth, CPU, and I/O starvation,
        while ensuring the target torrent is unpaused/resumed.
        Returns set of existing torrent IDs.
        """
        existing_ids = set()
        try:
            elem_req = urllib.request.Request("http://127.0.0.1:65220/torrents/list", headers={"User-Agent": "Kodi"})
            with urllib.request.urlopen(elem_req, timeout=1.5) as r:
                torrents = json.loads(r.read().decode())
                target_norm = exclude_hash.lower() if exclude_hash else None
                for t in torrents:
                    tid = str(t.get("id") or "").lower()
                    t_hash = (t.get("info_hash") or tid).lower()
                    if not tid and not t_hash:
                        continue
                    existing_ids.add(t_hash)
                    status = t.get("status")
                    if target_norm and (t_hash == target_norm or tid == target_norm):
                        if status == "Paused":
                            resume_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/resume/{tid}")
                            urllib.request.urlopen(resume_req, timeout=1.5)
                            log(f"Resumed active Elementum target torrent: {tid}", level="info")
                    else:
                        if status != "Paused":
                            pause_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/pause/{tid}")
                            urllib.request.urlopen(pause_req, timeout=1.5)
                            log(f"Paused competing Elementum torrent: {tid} ({t.get('name', '')})", level="info")
        except Exception as e:
            log(f"Notice: Elementum pause/resume check: {e}", level="debug")
        return existing_ids

    def try_recover_elementum(self):
        """
        Attempts to auto-heal Elementum when the daemon is unresponsive.
        Restarts Elementum via Kodi JSON-RPC (Addons.SetAddonEnabled toggle).
        """
        log("Attempting Elementum auto-heal via Kodi JSON-RPC...", level="info")
        try:
            disable_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": "plugin.video.elementum", "enabled": False},
                "id": 1
            })
            xbmc.executeJSONRPC(disable_payload)
            xbmc.sleep(800)

            enable_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": "plugin.video.elementum", "enabled": True},
                "id": 2
            })
            xbmc.executeJSONRPC(enable_payload)

            for _ in range(7):
                xbmc.sleep(500)
                if self.is_engine_alive("Elementum"):
                    log("Elementum successfully auto-healed and alive!", level="info")
                    return True
        except Exception as e:
            log(f"Elementum auto-heal attempt error: {e}", level="warning")
        return False

    def _ensure_elementum_ready(self):
        """Ensures Elementum is active and properly configured to avoid memory deadlock."""
        from resources.lib import dependencies
        dependencies.ensure_kodi_settings_for_elementum()
        dependencies.ensure_elementum_config()

        if self.is_engine_alive("Elementum"):
            return True

        if Config.elementum_auto_heal() and self.try_recover_elementum():
            return True

        try:
            import xbmc
            import xbmcgui
            if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
                if dependencies.prompt_install_elementum():
                    for _ in range(16):
                        xbmc.sleep(500)
                        if self.is_engine_alive("Elementum"):
                            return True
                    return True
            else:
                # Elementum is installed, but daemon is not responding
                confirm = xbmcgui.Dialog().yesno(
                    "Elementum no responde",
                    "El motor Elementum está instalado pero su proceso interno aún no responde.\n\n"
                    "¿Deseas reparar y configurar Elementum automáticamente con los permisos y dependencias correctos?",
                    yeslabel="Reparar Elementum",
                    nolabel="Cancelar"
                )
                if confirm:
                    if dependencies.install_elementum():
                        for _ in range(16):
                            xbmc.sleep(500)
                            if self.is_engine_alive("Elementum"):
                                return True
                        return True
        except Exception as e:
            log(f"Error ensuring elementum ready: {e}", level="warning")
        return False

    @staticmethod
    def _ensure_lan_bypass(host):
        """
        On CoreELEC/Linux, ensures that local LAN traffic to the TorrServer PC
        bypasses any active WireGuard VPN tunnel by adding a /32 host route.
        """
        if not host or host in ("127.0.0.1", "localhost"):
            return
        try:
            import subprocess, shutil
            if shutil.which("ip") is not None:
                parts = host.split(".")
                if len(parts) == 4 and all(p.isdigit() for p in parts):
                    if host.startswith("192.168.") or host.startswith("10.") or host.startswith("172."):
                        subprocess.run(
                            ["ip", "route", "replace", f"{host}/32", "via", "192.168.1.1"],
                            timeout=1,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
        except Exception:
            pass

    def resolve_torrserver_stream(self, uri, file_idx=None, stream_title="", info_hash=None):
        """
        Resolves torrent stream via TorrServer MatriX HTTP streaming endpoint.
        Returns direct HTTP playable URL.
        """
        host = Config.torrserver_host().strip() or "127.0.0.1"
        port = str(Config.torrserver_port()).strip() or "8090"
        auth_required = Config.torrserver_auth()
        user = Config.torrserver_user().strip()
        password = Config.torrserver_pass()

        self._ensure_lan_bypass(host)

        # Ultra-fast pre-flight check (< 0.8s): fail immediately if TorrServer is offline
        if not self.is_engine_alive("TorrServer", timeout=0.8):
            log(f"TorrServer at {host}:{port} is unreachable or offline", level="info")
            return None

        base_api_url = f"http://{host}:{port}"
        headers = {"User-Agent": "Kodi", "Content-Type": "application/json"}
        if auth_required and user:
            import base64
            cred = base64.b64encode(f"{user}:{password}".encode()).decode()
            headers["Authorization"] = f"Basic {cred}"

        if not info_hash and uri:
            match = re.search(r"urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", uri, re.I)
            if match:
                raw_hash = match.group(1)
                if len(raw_hash) == 40:
                    info_hash = raw_hash.lower()
                elif len(raw_hash) == 32:
                    import base64
                    try:
                        info_hash = base64.b32decode(raw_hash.upper()).hex().lower()
                    except Exception:
                        info_hash = raw_hash.lower()

        # Keep TorrServer in RAM streaming mode (never dump raw chunk caches to disk)
        save_db = Config.download_playback_enabled()
        try:
            sets_payload = json.dumps({
                "action": "set",
                "sets": {
                    "UseDisk": False,
                    "TorrentsSavePath": "",
                }
            }).encode("utf-8")
            s_req = urllib.request.Request(f"{base_api_url}/settings", data=sets_payload, headers=headers)
            with urllib.request.urlopen(s_req, timeout=1.0) as s_resp:
                pass
        except Exception:
            pass

        # Add torrent to TorrServer session (save_to_db=save_db)
        try:
            add_payload = json.dumps({
                "action": "add",
                "link": uri or (f"magnet:?xt=urn:btih:{info_hash}" if info_hash else ""),
                "title": stream_title or "Stream",
                "save_to_db": save_db
            }).encode("utf-8")
            req = urllib.request.Request(f"{base_api_url}/torrents", data=add_payload, headers=headers)
            with urllib.request.urlopen(req, timeout=2.5) as resp:
                pass
        except Exception as e:
            log(f"TorrServer add session notice: {e}", level="warning")
            return None

        best_id = None
        chosen_filename = None

        # Fetch file list from TorrServer (quick check up to 4 attempts x 150ms)
        if info_hash:
            get_payload = json.dumps({"action": "get", "hash": info_hash}).encode("utf-8")
            for _ in range(4):
                try:
                    req = urllib.request.Request(f"{base_api_url}/torrents", data=get_payload, headers=headers)
                    with urllib.request.urlopen(req, timeout=1.0) as resp:
                        data = json.loads(resp.read().decode())
                        file_stats = data.get("file_stats") or []
                        if file_stats:
                            if file_idx is not None and isinstance(file_idx, int) and 0 <= file_idx < len(file_stats):
                                best_id = file_stats[file_idx].get("id")
                                chosen_filename = file_stats[file_idx].get("path", "").replace("\\", "/").split("/")[-1]
                            elif file_idx is None:
                                video_exts = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.ts', '.m2ts')
                                v_files = [f for f in file_stats if any(f.get("path", "").lower().endswith(ext) for ext in video_exts)]
                                pool = v_files if v_files else file_stats
                                largest = max(pool, key=lambda x: x.get("length", 0))
                                best_id = largest.get("id")
                                chosen_filename = largest.get("path", "").replace("\\", "/").split("/")[-1]
                            break
                except Exception:
                    pass
                xbmc.sleep(150)

        if best_id is None:
            if file_idx is not None and isinstance(file_idx, int):
                best_id = file_idx + 1
            else:
                best_id = 1

        if not chosen_filename:
            safe_name = re.sub(r'[/\\?%*:|"<>]', '.', stream_title or "video").strip()
            if not any(safe_name.lower().endswith(ext) for ext in ('.mkv', '.mp4', '.avi', '.ts')):
                safe_name += ".mkv"
            chosen_filename = safe_name

        auth_str = f"{quote(user)}:{quote(password)}@" if auth_required and user else ""
        encoded_filename = quote(chosen_filename)
        encoded_link = quote(uri or f"magnet:?xt=urn:btih:{info_hash}", safe="")
        stream_url = f"http://{auth_str}{host}:{port}/stream/{encoded_filename}?link={encoded_link}&index={best_id}&play"
        log(f"TorrServer resolved direct stream: {stream_url[:120]}...", level="info")
        ui.show_notification(f"Reproduciendo con TorrServer ({host})", time=2500)
        return stream_url

    def resolve_elementum_stream(self, uri, file_idx=None, info_hash=None):
        """
        Emulates Elementum's native playback architecture:
        Directly requests http://127.0.0.1:65220/play?uri=...
        Elementum Go daemon displays the native Kodi progress dialog while buffering.
        When buffering reaches 100%, Elementum returns a 302 redirect with the direct HTTP stream URL:
        http://127.0.0.1:65220/files/...
        Returns the direct HTTP stream URL, or None if user cancelled or error.
        """
        if not self.is_engine_alive("Elementum"):
            if Config.elementum_auto_heal():
                if not self.try_recover_elementum():
                    return None
            else:
                return None

        if not info_hash and uri:
            match = re.search(r"urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", uri, re.I)
            if match:
                raw_hash = match.group(1)
                if len(raw_hash) == 40:
                    info_hash = raw_hash.lower()
                elif len(raw_hash) == 32:
                    import base64
                    try:
                        info_hash = base64.b32decode(raw_hash.upper()).hex().lower()
                    except Exception:
                        info_hash = raw_hash.lower()

        # Build Elementum play URL (do not force doresume=false so Elementum can reuse fastresume cache)
        encoded = quote(uri, safe="")
        play_url = f"http://127.0.0.1:65220/play?uri={encoded}"

        if file_idx is not None:
            play_url += f"&oindex={file_idx}"

        opener = urllib.request.build_opener(NoRedirectHandler())
        opener.addheaders = [("User-Agent", "plugin.video.elementum")]

        log(f"Resolving stream via Elementum daemon: {play_url[:120]}...", level="info")

        try:
            # 300s timeout so Python doesn't prematurely interrupt Kodi's buffering dialog
            res = opener.open(play_url, timeout=300)
            if res:
                loc = res.headers.get("Location") or res.geturl()
                if loc and loc.startswith("http"):
                    log(f"Elementum resolved direct stream: {loc}", level="info")
                    return loc
        except urllib.error.HTTPError as he:
            # Elementum sends 302 Found redirect when buffering reaches 100%
            if he.code in (301, 302, 303, 307):
                loc = he.headers.get("Location")
                if loc and loc.startswith("http"):
                    log(f"Elementum resolved direct stream via HTTP {he.code}: {loc}", level="info")
                    return loc
            log(f"Elementum daemon resolve HTTP error {he.code}: {he}", level="warning")
            if info_hash:
                try:
                    pause_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/pause/{info_hash}")
                    urllib.request.urlopen(pause_req, timeout=1.5)
                except Exception:
                    pass
            return None
        except Exception as e:
            log(f"Elementum daemon resolve ended: {e}", level="info")
            if info_hash:
                try:
                    pause_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/pause/{info_hash}")
                    urllib.request.urlopen(pause_req, timeout=1.5)
                    log(f"Paused Elementum torrent after aborted resolution: {info_hash}", level="info")
                except Exception:
                    pass
            return None

        return None

    def resolve(self, stream):
        """
        Resolve a stream dict or StreamRelease to a playable URL.
        Delegates to MediaCore Playback Orchestrator (TorrServer -> Debrid -> Elementum -> Direct).
        """
        try:
            from resources.lib.mediacore.models import StreamRelease
            from resources.lib.mediacore.orchestrator import MediaCore

            if isinstance(stream, dict):
                info_h = stream.get("infoHash") or stream.get("info_hash") or ""
                url = stream.get("url", "")
                if not info_h and "urn:btih:" in url:
                    match = re.search(r"urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", url, re.I)
                    if match:
                        info_h = match.group(1)

                rel = StreamRelease(
                    title=(stream.get("title") or stream.get("name") or "Stream").split("\n")[0].strip(),
                    info_hash=info_h,
                    file_idx=stream.get("fileIdx"),
                    url=url,
                    is_debrid_cached=stream.get("_debrid_cached", False),
                    debrid_provider=stream.get("_debrid_provider", ""),
                    source_name=stream.get("_addon") or stream.get("name") or "Torrent",
                )
            elif hasattr(stream, "info_hash"):
                rel = stream
            else:
                return None

            result = MediaCore().resolve_playback(rel)
            if result and result.success:
                return result.url
            return None
        except Exception as e:
            log(f"MediaCore resolution exception: {e}", level="error")
            return None

    def resolve_magnet(self, magnet_uri):
        """Resolve a raw magnet URI (from manual input) via MediaCore."""
        from resources.lib.mediacore.models import StreamRelease
        from resources.lib.mediacore.orchestrator import MediaCore

        rel = StreamRelease(
            title="Manual Magnet",
            url=magnet_uri,
            source_name="Manual",
        )
        res = MediaCore().resolve_playback(rel)
        if res and res.success:
            return res.url, "direct"
        return None, "direct"

    def _check_privacy_and_engine(self, engine_url):
        if Config.strict_debrid():
            log("P2P blocked by Strict Debrid setting", level="warning")
            import xbmcgui
            xbmcgui.Dialog().ok(
                "Strict Debrid",
                "Reproducción P2P local bloqueada por seguridad (Strict Debrid activo)."
            )
            return None

        from resources.lib.cache import CacheDB
        cache = CacheDB()
        if not cache.get("_p2p_privacy_warned"):
            import xbmcgui
            confirm = xbmcgui.Dialog().yesno(
                "Advertencia de Privacidad P2P",
                "Vas a reproducir mediante un motor P2P local (TorrServer/Elementum).\n"
                "Tu dirección IP será pública en la red Kademlia DHT.\n"
                "¿Deseas continuar con la reproducción?"
            )
            if not confirm:
                return None
            cache.set("_p2p_privacy_warned", True, ttl=31536000)

        return engine_url

    def is_engine_alive(self, engine_name, timeout=None):
        try:
            if engine_name == "TorrServer":
                host = (Config.torrserver_host() or "127.0.0.1").strip()
                try:
                    port = int(Config.torrserver_port())
                except (ValueError, TypeError):
                    port = 8090
                t = timeout if timeout is not None else (0.5 if host in ("127.0.0.1", "localhost") else 1.0)
                self._ensure_lan_bypass(host)
                import socket
                try:
                    with socket.create_connection((host, port), timeout=t) as s:
                        s.settimeout(t)
                        s.sendall(b"GET /echo HTTP/1.1\r\nHost: " + host.encode() + b"\r\nConnection: close\r\n\r\n")
                        resp = s.recv(512)
                        return (b"200" in resp or b"MatriX" in resp or b"401" in resp)
                except Exception as se:
                    log(f"TorrServer probe notice ({host}:{port}): {se}", level="debug")
                    return False
            elif engine_name == "Elementum":
                import urllib.request
                req = urllib.request.Request("http://127.0.0.1:65220/", headers={"User-Agent": "Kodi"})
                with urllib.request.urlopen(req, timeout=1.0) as r:
                    return True
            elif engine_name == "Torrest":
                import urllib.request
                req = urllib.request.Request("http://127.0.0.1:61235/torrents", headers={"User-Agent": "Kodi"})
                with urllib.request.urlopen(req, timeout=1.0) as r:
                    return True
        except Exception as e:
            log(f"is_engine_alive exception for {engine_name}: {e}", level="warning")
            return False
        return False

    def get_active_engine(self):
        engine = Config.torrent_engine()
        preflight = Config.torrent_preflight_check()

        # If user explicitly chose TorrServer, resolve() handles fast-probe (< 0.8s) and Elementum fallback
        if engine == "TorrServer":
            return "TorrServer"

        if engine == "Auto":
            if self.is_engine_alive("TorrServer", timeout=0.8):
                return "TorrServer"
            if self.is_engine_alive("Elementum"):
                return "Elementum"
            if Config.elementum_auto_heal() and self.try_recover_elementum():
                return "Elementum"
            if self.is_engine_alive("Torrest"):
                return "Torrest"
            return "TorrServer"

        if preflight:
            if engine == "Elementum" and not self.is_engine_alive("Elementum"):
                if Config.elementum_auto_heal() and self.try_recover_elementum():
                    return "Elementum"
                for _ in range(4):
                    xbmc.sleep(500)
                    if self.is_engine_alive("Elementum"):
                        return "Elementum"
                log("Elementum unreachable during preflight", level="warning")

        return engine

    def _to_engine_url(self, uri, stream):
        encoded = quote(uri, safe="")
        file_idx = stream.get("fileIdx") if isinstance(stream, dict) else None
        stream_title = (stream.get("title") or stream.get("name") or "").split("\n")[0].strip() if isinstance(stream, dict) else ""
        active = self.get_active_engine()

        if active == "TorrServer":
            return self.resolve_torrserver_stream(uri, file_idx, stream_title)
        elif active == "Elementum":
            base = f"plugin://plugin.video.elementum/play?uri={encoded}"
            if file_idx is not None:
                base += f"&oindex={file_idx}"
            return base
        elif active == "Torrest":
            if uri.startswith("magnet:"):
                base = f"plugin://plugin.video.torrest/play_magnet?magnet={encoded}"
            else:
                base = f"plugin://plugin.video.torrest/play_url?url={encoded}"
            if file_idx is not None:
                base += f"&file_id={file_idx}"
            return base
        return uri

    def _enrich_magnet(self, magnet_uri, stream=None):
        if not magnet_uri or not magnet_uri.startswith("magnet:"):
            return magnet_uri

        lower_mag = magnet_uri.lower()
        extra_trackers = []
        if isinstance(stream, dict):
            sources = stream.get("sources", []) or []
            for s in sources:
                if isinstance(s, str):
                    if s.startswith("tracker:"):
                        extra_trackers.append(s[len("tracker:"):].strip())
                    elif s.startswith("http://") or s.startswith("https://") or s.startswith("udp://"):
                        extra_trackers.append(s.strip())
            for tr in (stream.get("trackers", []) or []):
                if isinstance(tr, str) and tr.strip():
                    extra_trackers.append(tr.strip())

        all_candidates = extra_trackers + TRACKERS
        for tr in all_candidates:
            if not tr:
                continue
            quoted_tr = quote(tr, safe="")
            if quoted_tr.lower() not in lower_mag and tr.lower() not in lower_mag:
                magnet_uri += f"&tr={quoted_tr}"
                lower_mag += f"&tr={quoted_tr.lower()}"

        return magnet_uri

    def _build_magnet(self, info_hash, stream):
        title = stream.get("title", "") or stream.get("name", "Unknown") if isinstance(stream, dict) else "Unknown"
        dn = re.sub(r"\[.*?\]", "", title.split("\n")[0]).strip()
        dn = re.sub(r"\s+", ".", dn)[:100]

        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(dn, safe='')}"
        return self._enrich_magnet(magnet, stream)

    # ── Sorting & Filtering ────────────────────────────────
    def filter_by_title_match(self, streams, title="", original_title="", media_type="movie", season=None, episode=None):
        """
        Filters out irrelevant torrents (e.g. DHT search false positives like 'Boston Blue' for 'Bluey').
        Stremio addon streams (which query exact IMDB IDs) are always trusted.
        """
        if not streams or (not title and not original_title):
            return streams

        candidates = [t for t in [title, original_title] if t]

        filtered = []
        for s in streams:
            addon = s.get("_addon", "")
            # If stream is from Stremio addons with exact IMDB ID, preserve it
            if addon and addon not in ("Apibay", "Bitsearch", "SolidTorrents", "Apibay Trending", "Unknown"):
                filtered.append(s)
                continue

            stream_title = s.get("title", "") or s.get("name", "")
            if not stream_title:
                continue

            matched = any(
                self._is_title_match(stream_title, expected, media_type, season, episode)
                for expected in candidates
            )
            if matched:
                filtered.append(s)

        # If strict filtering filtered everything out, keep non-DHT streams if available
        if not filtered:
            fallback = [s for s in streams if s.get("_addon") not in ("Apibay", "Bitsearch", "SolidTorrents", "Apibay Trending")]
            return fallback if fallback else streams

        return filtered

    def _is_title_match(self, torrent_title, expected_title, media_type="movie", season=None, episode=None):
        if not expected_title or not torrent_title:
            return True

        clean_torrent = re.sub(r"[\._\-\+\[\]\(\)\:\,]+", " ", torrent_title).lower()
        clean_expected = re.sub(r"[\._\-\+\[\]\(\)\:\,]+", " ", expected_title).lower()

        base_name = re.sub(r"\bs\d+e\d+\b", "", clean_expected, flags=re.IGNORECASE)
        base_name = re.sub(r"\b\d+x\d+\b", "", base_name, flags=re.IGNORECASE)
        base_name = re.sub(r"\b\d{4}\b", "", base_name)
        base_name = re.sub(r"\s+", " ", base_name).strip()

        if not base_name:
            base_name = clean_expected.strip()

        words = [re.escape(w) for w in base_name.split() if len(w) > 0]
        if not words:
            return True

        pattern = r"\b" + r"[\s\._\-]+".join(words) + r"\b"
        if not re.search(pattern, clean_torrent, re.IGNORECASE):
            return False

        if media_type == "series" and season is not None and episode is not None:
            try:
                s_int = int(season)
                e_int = int(episode)
                ep_patterns = [
                    rf"\bs0*{s_int}\s*e0*{e_int}\b",
                    rf"\b0*{s_int}x0*{e_int}\b",
                    rf"\bseason\s*0*{s_int}\s*episode\s*0*{e_int}\b",
                    rf"\bs0*{s_int}\b(?!\s*e\d+)",
                    rf"\bseason\s*0*{s_int}\b",
                    rf"\btemporada\s*0*{s_int}\b",
                    r"\bcomplete\s*(?:series|tv|boxset|season)?\b",
                    r"\ball\s*seasons\b",
                    r"\bseasons?\s*\d+(?:\s*(?:-|to|\sand\s|,|\s)\s*\d+)*\b",
                    r"\bs\d+\s*-\s*s\d+\b"
                ]
                has_ep = any(re.search(p, clean_torrent, re.IGNORECASE) for p in ep_patterns)
                if not has_ep:
                    return False
            except (ValueError, TypeError):
                pass

        return True

    def filter_by_quality(self, streams):
        preferred = Config.torrent_quality()
        if preferred == "Any":
            return streams
        pattern = QUALITY_PATTERNS.get(preferred)
        if not pattern:
            return streams
        filtered = [
            s for s in streams
            if pattern.search(s.get("title", "") or s.get("name", ""))
        ]
        return filtered if filtered else streams

    def filter_spanish(self, streams):
        """Filter/tag streams based on Spanish language preference."""
        mode = Config.spanish_filter_mode()
        if mode == "off":
            return streams

        for s in streams:
            title = s.get("title", "") or s.get("name", "")
            s["_spanish"] = detect_spanish(title)

        if mode == "only":
            variant_pref = Config.spanish_variant()
            filtered = []
            for s in streams:
                info = s.get("_spanish", {})
                if not info.get("is_spanish"):
                    continue
                if variant_pref == "castellano" and info.get("variant") not in ("CAST", "ESP"):
                    continue
                if variant_pref == "latino" and info.get("variant") not in ("LAT", "LAT-MX"):
                    continue
                if variant_pref == "dual" and info.get("variant") != "DUAL":
                    continue
                filtered.append(s)
            return filtered if filtered else streams

        return streams

    def sort_streams(self, streams):
        """
        Intelligent stream sorting:
        1. Real-Debrid cached streams always prioritized (+10,000,000)
        2. Healthy swarms (seeds >= 3) prioritized.
        3. Dead streams (0 seeds, un-cached) heavily penalized (-500,000).
        4. Spanish boost applied to healthy streams (seeds >= 3 or RD cached).
        5. Ties resolved by user preference (Seeds, Quality, Size).
        """
        sort_by = Config.torrent_sort()
        spanish_on = Config.spanish_boost() and Config.spanish_filter_mode() != "off"

        def _sort_key(s):
            is_rd = bool((s.get("_rd_cached") or any(k in str(s) for k in ("[RD+]", "[AD+]", "[PM+]", "[TB+]", "[DL+]"))) and Config.rd_priority())
            seeds = self._extract_seeds(s)

            # Base health score
            if is_rd:
                health_score = 10000000
            elif seeds <= 0:
                health_score = -500000  # Dead swarm penalty
            elif seeds < 3:
                health_score = -100000 + (seeds * 100)  # Unhealthy swarm penalty
            else:
                health_score = min(seeds, 500) * 100  # Up to 50,000 points (healthy swarms prioritize speed & stability)

            # Single-file torrent bonus (far more reliable on P2P engines than multi-file season packs)
            file_bonus = 0
            if s.get("fileIdx") is None:
                file_bonus = 1000

            # Spanish boost (only granted to healthy streams or RD cached)
            esp_boost = 0
            if spanish_on and (is_rd or seeds >= 3):
                esp_score = get_spanish_boost(s)
                if esp_score >= 50:
                    esp_boost = 50000 + (esp_score * 100)

            # Preference score
            pref_score = 0
            if sort_by == "Seeds":
                pref_score = seeds * 50
            elif sort_by == "Quality":
                from resources.lib.rtn import RTN
                pref_score = RTN.get_quality_score(s) * 10
            elif sort_by == "Size":
                pref_score = int(self._extract_size_gb(s) * 100)

            return health_score + file_bonus + esp_boost + pref_score

        return sorted(streams, key=_sort_key, reverse=True)

    def _extract_seeds(self, s):
        from resources.lib.rtn import RTN
        return RTN.parse(s).get("seeds", 0)

    def _quality_score(self, s):
        from resources.lib.rtn import RTN
        return RTN.get_quality_score(s)

    def _extract_size_gb(self, s):
        from resources.lib.rtn import RTN
        sz_str = RTN.parse(s).get("size", "")
        if "gb" in sz_str.lower():
            m = re.search(r"([\d.]+)", sz_str)
            if m:
                return float(m.group(1))
        elif "mb" in sz_str.lower():
            m = re.search(r"([\d.]+)", sz_str)
            if m:
                return float(m.group(1)) / 1024
        return 0

    # ── Display labels ─────────────────────────────────────
    def get_quality_label(self, stream):
        from resources.lib.rtn import RTN
        meta = RTN.parse(stream)
        res = meta["resolution"]
        if res == "4K":
            return "[COLOR gold][B]4K[/B][/COLOR]"
        if res == "1080p":
            return "[COLOR lime]1080p[/COLOR]"
        if res == "720p":
            return "[COLOR cyan]720p[/COLOR]"
        if res == "480p":
            return "[COLOR grey]480p[/COLOR]"
        return ""

    def get_seeds_label(self, stream):
        from resources.lib.rtn import RTN
        seeds = RTN.parse(stream).get("seeds", 0)
        if seeds >= 50:
            return f"[COLOR lime]S:{seeds}[/COLOR]"
        elif seeds >= 10:
            return f"[COLOR yellow]S:{seeds}[/COLOR]"
        elif seeds > 0:
            return f"[COLOR orange]S:{seeds}[/COLOR]"
        return "[COLOR red]S:0[/COLOR]"

    def get_size_label(self, stream):
        from resources.lib.rtn import RTN
        sz = RTN.parse(stream).get("size", "")
        return f"[COLOR lightgrey]{sz}[/COLOR]" if sz else ""

    def get_rd_label(self, stream):
        if stream.get("_rd_cached"):
            b = stream.get("_debrid_provider") or "RD"
            return f"[COLOR magenta][B][{b}+][/B][/COLOR]"
        return ""

    def get_spanish_tag(self, stream):
        from resources.lib.rtn import RTN
        meta = RTN.parse(stream)
        lang = meta["language"]
        if lang == "CAST":
            return "[COLOR orange][B]Castellano[/B][/COLOR]"
        elif lang == "LAT":
            return "[COLOR deepskyblue][B]Latino[/B][/COLOR]"
        elif lang == "DUAL":
            return "[COLOR gold][B]Dual Audio[/B][/COLOR]"
        elif lang == "MULTI":
            return "[COLOR mediumpurple][B]Multi Audio[/B][/COLOR]"
        elif lang == "VOSE":
            return "[COLOR lightgreen][B]VOSE[/B][/COLOR]"
        return "[COLOR white][V.O.][/COLOR]"
