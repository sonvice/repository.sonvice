# -*- coding: utf-8 -*-
"""
TorrentResolver — Resolve streams via Elementum, Quasar, or Real-Debrid.
v2: Added RD support. RD cached streams become direct HTTP = instant play.
"""
import re
from urllib.parse import quote
import urllib.request
import urllib.response
import json

from resources.lib.config import Config
from resources.lib.debrid import RealDebrid
from resources.lib.spanish import detect_spanish, get_spanish_label, get_spanish_boost
from resources.lib.logger import log
from resources.lib import ui
import xbmc
import xbmcgui

QUALITY_PATTERNS = {
    "4K":    re.compile(r"(2160p|4k|uhd)", re.IGNORECASE),
    "1080p": re.compile(r"1080p", re.IGNORECASE),
    "720p":  re.compile(r"720p", re.IGNORECASE),
    "480p":  re.compile(r"(480p|sd)", re.IGNORECASE),
}

TRACKERS = [
    # Tier-1 High Availability Open Trackers (Fast UDP & HTTP fallback)
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://explodie.org:6969/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "http://tracker.opentrackr.org:1337/announce",
    "https://tracker.tamersunion.org:443/announce",
]


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.response.addinfourl(fp, headers, headers.get("Location", ""), code)
        return infourl
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302


class TorrentResolver:
    def __init__(self):
        self.engine = Config.torrent_engine()
        self.rd = RealDebrid()

    def pause_elementum_torrents(self, exclude_hash=None):
        """
        Pause competing torrents in Elementum to prevent bandwidth, CPU, and I/O starvation,
        while ensuring the target torrent is unpaused/resumed.
        Returns set of existing torrent IDs.
        """
        existing_ids = set()
        try:
            elem_req = urllib.request.Request("http://127.0.0.1:65220/torrents/list", headers={"User-Agent": "Kodi"})
            with urllib.request.urlopen(elem_req, timeout=1.5) as r:
                torrents = json.loads(r.read().decode())
                target_norm = exclude_hash.lower() if exclude_hash else None
                for t in torrents:
                    tid = str(t.get("id") or "").lower()
                    t_hash = (t.get("info_hash") or tid).lower()
                    if not tid and not t_hash:
                        continue
                    existing_ids.add(t_hash)
                    status = t.get("status")
                    if target_norm and (t_hash == target_norm or tid == target_norm):
                        if status == "Paused":
                            resume_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/resume/{tid}")
                            urllib.request.urlopen(resume_req, timeout=1.5)
                            log(f"Resumed active Elementum target torrent: {tid}", level="info")
                    else:
                        if status != "Paused":
                            pause_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/pause/{tid}")
                            urllib.request.urlopen(pause_req, timeout=1.5)
                            log(f"Paused competing Elementum torrent: {tid} ({t.get('name', '')})", level="info")
        except Exception as e:
            log(f"Notice: Elementum pause/resume check: {e}", level="debug")
        return existing_ids

    def try_recover_elementum(self):
        """
        Attempts to auto-heal Elementum when the daemon is unresponsive.
        Restarts Elementum via Kodi JSON-RPC (Addons.SetAddonEnabled toggle).
        """
        log("Attempting Elementum auto-heal via Kodi JSON-RPC...", level="info")
        try:
            disable_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": "plugin.video.elementum", "enabled": False},
                "id": 1
            })
            xbmc.executeJSONRPC(disable_payload)
            xbmc.sleep(800)

            enable_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": "plugin.video.elementum", "enabled": True},
                "id": 2
            })
            xbmc.executeJSONRPC(enable_payload)

            for _ in range(7):
                xbmc.sleep(500)
                if self.is_engine_alive("Elementum"):
                    log("Elementum successfully auto-healed and alive!", level="info")
                    return True
        except Exception as e:
            log(f"Elementum auto-heal attempt error: {e}", level="warning")
        return False

    def resolve_torrserver_stream(self, uri, file_idx=None, stream_title="", info_hash=None):
        """
        Resolves torrent stream via TorrServer MatriX HTTP streaming endpoint.
        Returns direct HTTP playable URL.
        """
        if not self.is_engine_alive("TorrServer"):
            return None

        host = Config.torrserver_host().strip() or "127.0.0.1"
        port = str(Config.torrserver_port()).strip() or "8090"
        auth_required = Config.torrserver_auth()
        user = Config.torrserver_user().strip()
        password = Config.torrserver_pass()

        base_api_url = f"http://{host}:{port}"
        headers = {"User-Agent": "Kodi", "Content-Type": "application/json"}
        if auth_required and user:
            import base64
            cred = base64.b64encode(f"{user}:{password}".encode()).decode()
            headers["Authorization"] = f"Basic {cred}"

        if not info_hash and uri:
            match = re.search(r"urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", uri, re.I)
            if match:
                raw_hash = match.group(1)
                if len(raw_hash) == 40:
                    info_hash = raw_hash.lower()
                elif len(raw_hash) == 32:
                    import base64
                    try:
                        info_hash = base64.b32decode(raw_hash.upper()).hex().lower()
                    except Exception:
                        info_hash = raw_hash.lower()

        # Add torrent to TorrServer memory session (save_to_db=False)
        try:
            add_payload = json.dumps({
                "action": "add",
                "link": uri or (f"magnet:?xt=urn:btih:{info_hash}" if info_hash else ""),
                "title": stream_title or "Stream",
                "save_to_db": False
            }).encode("utf-8")
            req = urllib.request.Request(f"{base_api_url}/torrents", data=add_payload, headers=headers)
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                pass
        except Exception as e:
            log(f"TorrServer add session notice: {e}", level="debug")

        best_id = None
        chosen_filename = None

        # Fetch file list from TorrServer
        if info_hash:
            get_payload = json.dumps({"action": "get", "hash": info_hash}).encode("utf-8")
            for _ in range(8):
                try:
                    req = urllib.request.Request(f"{base_api_url}/torrents", data=get_payload, headers=headers)
                    with urllib.request.urlopen(req, timeout=2.0) as resp:
                        data = json.loads(resp.read().decode())
                        file_stats = data.get("file_stats") or []
                        if file_stats:
                            if file_idx is not None and isinstance(file_idx, int) and 0 <= file_idx < len(file_stats):
                                best_id = file_stats[file_idx].get("id")
                                chosen_filename = file_stats[file_idx].get("path", "").replace("\\", "/").split("/")[-1]
                            elif file_idx is None:
                                video_exts = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.ts', '.m2ts')
                                v_files = [f for f in file_stats if any(f.get("path", "").lower().endswith(ext) for ext in video_exts)]
                                pool = v_files if v_files else file_stats
                                largest = max(pool, key=lambda x: x.get("length", 0))
                                best_id = largest.get("id")
                                chosen_filename = largest.get("path", "").replace("\\", "/").split("/")[-1]
                            break
                except Exception:
                    pass
                xbmc.sleep(250)

        if best_id is None:
            if file_idx is not None and isinstance(file_idx, int):
                best_id = file_idx + 1
            else:
                best_id = 1

        if not chosen_filename:
            safe_name = re.sub(r'[/\\?%*:|"<>]', '.', stream_title or "video").strip()
            if not any(safe_name.lower().endswith(ext) for ext in ('.mkv', '.mp4', '.avi', '.ts')):
                safe_name += ".mkv"
            chosen_filename = safe_name

        auth_str = f"{quote(user)}:{quote(password)}@" if auth_required and user else ""
        encoded_filename = quote(chosen_filename)
        encoded_link = quote(uri or f"magnet:?xt=urn:btih:{info_hash}", safe="")
        stream_url = f"http://{auth_str}{host}:{port}/stream/{encoded_filename}?link={encoded_link}&index={best_id}&play"
        log(f"TorrServer resolved direct stream: {stream_url[:120]}...", level="info")
        ui.show_notification(f"Reproduciendo con TorrServer ({host}) 🚀", time=2500)
        return stream_url

    def resolve_elementum_stream(self, uri, file_idx=None, info_hash=None):
        """
        Emulates Elementum's native playback architecture:
        Directly requests http://127.0.0.1:65220/play?uri=...
        Elementum Go daemon displays the native Kodi progress dialog while buffering.
        When buffering reaches 100%, Elementum returns a 302 redirect with the direct HTTP stream URL:
        http://127.0.0.1:65220/files/...
        Returns the direct HTTP stream URL, or None if user cancelled or error.
        """
        if not self.is_engine_alive("Elementum"):
            if Config.elementum_auto_heal():
                if not self.try_recover_elementum():
                    return None
            else:
                return None

        if not info_hash and uri:
            match = re.search(r"urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", uri, re.I)
            if match:
                raw_hash = match.group(1)
                if len(raw_hash) == 40:
                    info_hash = raw_hash.lower()
                elif len(raw_hash) == 32:
                    import base64
                    try:
                        info_hash = base64.b32decode(raw_hash.upper()).hex().lower()
                    except Exception:
                        info_hash = raw_hash.lower()

        # Build Elementum play URL (do not force doresume=false so Elementum can reuse fastresume cache)
        encoded = quote(uri, safe="")
        play_url = f"http://127.0.0.1:65220/play?uri={encoded}"

        if file_idx is not None:
            play_url += f"&oindex={file_idx}"

        opener = urllib.request.build_opener(NoRedirectHandler())
        opener.addheaders = [("User-Agent", "plugin.video.elementum")]

        log(f"Resolving stream via Elementum daemon: {play_url[:120]}...", level="info")

        try:
            # 300s timeout so Python doesn't prematurely interrupt Kodi's buffering dialog
            res = opener.open(play_url, timeout=300)
            if res and res.getcode() in (301, 302, 303, 307):
                loc = res.geturl()
                if loc and loc.startswith("http"):
                    log(f"Elementum resolved direct stream: {loc}", level="info")
                    return loc
        except Exception as e:
            log(f"Elementum daemon resolve ended: {e}", level="info")
            if info_hash:
                try:
                    pause_req = urllib.request.Request(f"http://127.0.0.1:65220/torrents/pause/{info_hash}")
                    urllib.request.urlopen(pause_req, timeout=1.5)
                    log(f"Paused Elementum torrent after aborted resolution: {info_hash}", level="info")
                except Exception:
                    pass
            return None

        return None

    def resolve(self, stream):
        """
        Resolve a stream dict to a playable URL.
        Priority: Real-Debrid (always tried first) > TorrServer/Elementum > Direct HTTP
        """
        url = stream.get("url", "")
        info_hash = stream.get("infoHash", "")
        file_idx = stream.get("fileIdx")
        stream_title = (stream.get("title") or stream.get("name") or "").split("\n")[0].strip()

        # ── Try Real-Debrid first for ANY hash (cache API is unreliable) ──
        if info_hash and self.rd.is_configured():
            log(f"Resolving via Real-Debrid: {info_hash}", level="info")
            rd_url = self.rd.resolve(info_hash, file_idx)
            if rd_url:
                return rd_url
            log("RD resolve failed, falling back to torrent engine", level="warning")

        # ── infoHash → magnet → engine ─────────────────────
        if info_hash:
            magnet = self._build_magnet(info_hash, stream)
            active = self.get_active_engine()
            if active == "TorrServer":
                checked = self._check_privacy_and_engine("TorrServer")
                if not checked:
                    return None
                resolved = self.resolve_torrserver_stream(magnet, file_idx, stream_title, info_hash=info_hash)
                if resolved:
                    return resolved
                log("TorrServer resolution failed, trying Elementum fallback...", level="warning")
                if self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum()):
                    return self.resolve_elementum_stream(magnet, file_idx, info_hash=info_hash)
                return None
            elif active == "Elementum" and (self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum())):
                checked = self._check_privacy_and_engine("Elementum")
                if not checked:
                    return None
                resolved = self.resolve_elementum_stream(magnet, file_idx, info_hash=info_hash)
                if resolved:
                    return resolved
                return None
            return self._check_privacy_and_engine(self._to_engine_url(magnet, stream))

        # ── magnet: link ───────────────────────────────────
        if url.startswith("magnet:"):
            # Try RD if enabled
            if self.rd.is_configured():
                rd_url = self.rd.resolve(url, file_idx)
                if rd_url:
                    return rd_url
            enriched = self._enrich_magnet(url, stream)
            active = self.get_active_engine()
            if active == "TorrServer":
                checked = self._check_privacy_and_engine("TorrServer")
                if not checked:
                    return None
                resolved = self.resolve_torrserver_stream(enriched, file_idx, stream_title)
                if resolved:
                    return resolved
                log("TorrServer resolution failed, trying Elementum fallback...", level="warning")
                if self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum()):
                    return self.resolve_elementum_stream(enriched, file_idx)
                return None
            elif active == "Elementum" and (self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum())):
                checked = self._check_privacy_and_engine("Elementum")
                if not checked:
                    return None
                resolved = self.resolve_elementum_stream(enriched, file_idx)
                if resolved:
                    return resolved
                return None
            return self._check_privacy_and_engine(self._to_engine_url(enriched, stream))

        # ── HTTP .torrent file ─────────────────────────────
        if url.startswith("http") and ".torrent" in url:
            active = self.get_active_engine()
            if active == "TorrServer":
                checked = self._check_privacy_and_engine("TorrServer")
                if not checked:
                    return None
                resolved = self.resolve_torrserver_stream(url, file_idx, stream_title)
                if resolved:
                    return resolved
                log("TorrServer resolution failed, trying Elementum fallback...", level="warning")
                if self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum()):
                    return self.resolve_elementum_stream(url, file_idx)
                return None
            elif active == "Elementum" and (self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum())):
                checked = self._check_privacy_and_engine("Elementum")
                if not checked:
                    return None
                resolved = self.resolve_elementum_stream(url, file_idx)
                if resolved:
                    return resolved
                return None
            return self._check_privacy_and_engine(self._to_engine_url(url, stream))

        # ── Direct HTTP stream ─────────────────────────────
        if url.startswith("http"):
            return url

        log(f"Unresolvable: {stream.get('title', '?')}", level="warning")
        return None

    def resolve_magnet(self, magnet_uri):
        """Resolve a raw magnet URI (from manual input)."""
        if self.rd.is_configured():
            rd_url = self.rd.resolve(magnet_uri)
            if rd_url:
                return rd_url, "direct"
        enriched = self._enrich_magnet(magnet_uri)
        active = self.get_active_engine()
        if active == "TorrServer":
            checked = self._check_privacy_and_engine("TorrServer")
            if not checked:
                return None, "direct"
            resolved = self.resolve_torrserver_stream(enriched, None, "Manual Magnet")
            if resolved:
                return resolved, "direct"
            log("TorrServer manual magnet resolve failed, trying Elementum fallback...", level="warning")
            if self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum()):
                resolved = self.resolve_elementum_stream(enriched, None)
                if resolved:
                    return resolved, "direct"
            return None, "direct"
        elif active == "Elementum" and (self.is_engine_alive("Elementum") or (Config.elementum_auto_heal() and self.try_recover_elementum())):
            checked = self._check_privacy_and_engine("Elementum")
            if not checked:
                return None, "plugin"
            resolved = self.resolve_elementum_stream(enriched, None)
            if resolved:
                return resolved, "direct"
            return None, "plugin"
        engine_url = self._to_engine_url(enriched, {})
        checked = self._check_privacy_and_engine(engine_url)
        if not checked:
            return None, "plugin"
        return checked, "plugin"

    def _check_privacy_and_engine(self, engine_url):
        if Config.strict_debrid():
            log("P2P blocked by Strict Debrid setting", level="warning")
            import xbmcgui
            xbmcgui.Dialog().ok(
                "Strict Debrid",
                "Reproducción P2P local bloqueada por seguridad (Strict Debrid activo)."
            )
            return None

        from resources.lib.cache import CacheDB
        cache = CacheDB()
        if not cache.get("_p2p_privacy_warned"):
            import xbmcgui
            confirm = xbmcgui.Dialog().yesno(
                "Advertencia de Privacidad P2P",
                "Vas a reproducir mediante un motor P2P local (TorrServer/Elementum).\n"
                "Tu dirección IP será pública en la red Kademlia DHT.\n"
                "¿Deseas continuar con la reproducción?"
            )
            if not confirm:
                return None
            cache.set("_p2p_privacy_warned", True, ttl=31536000)

        return engine_url

    def is_engine_alive(self, engine_name, timeout=None):
        import urllib.request
        import urllib.error
        try:
            if engine_name == "TorrServer":
                host = Config.torrserver_host()
                port = Config.torrserver_port()
                t = timeout or 3.0
                req = urllib.request.Request(f"http://{host}:{port}/echo", headers={"User-Agent": "Kodi"})
                if Config.torrserver_auth() and Config.torrserver_user():
                    import base64
                    cred = base64.b64encode(f"{Config.torrserver_user()}:{Config.torrserver_pass()}".encode()).decode()
                    req.add_header("Authorization", f"Basic {cred}")
                try:
                    with urllib.request.urlopen(req, timeout=t) as r:
                        return r.status in (200, 401)
                except urllib.error.HTTPError as he:
                    return he.code in (200, 401)
            elif engine_name == "Elementum":
                req = urllib.request.Request("http://127.0.0.1:65220/", headers={"User-Agent": "Kodi"})
                with urllib.request.urlopen(req, timeout=1.5) as r:
                    return True
            elif engine_name == "Torrest":
                req = urllib.request.Request("http://127.0.0.1:61235/torrents", headers={"User-Agent": "Kodi"})
                with urllib.request.urlopen(req, timeout=1.5) as r:
                    return True
        except Exception:
            return False
        return False

    def get_active_engine(self):
        engine = Config.torrent_engine()
        preflight = Config.torrent_preflight_check()

        if engine == "Auto":
            if self.is_engine_alive("TorrServer"):
                return "TorrServer"
            if self.is_engine_alive("Elementum"):
                return "Elementum"
            if Config.elementum_auto_heal() and self.try_recover_elementum():
                return "Elementum"
            if self.is_engine_alive("Torrest"):
                return "Torrest"
            return "Elementum"

        if preflight:
            if engine == "TorrServer" and not self.is_engine_alive("TorrServer"):
                log("TorrServer unreachable during preflight, falling back to Elementum", level="warning")
                ui.show_notification(f"TorrServer no responde ({Config.torrserver_host()}). Usando Elementum...", time=3500)
                if self.is_engine_alive("Elementum"):
                    return "Elementum"
                if Config.elementum_auto_heal() and self.try_recover_elementum():
                    return "Elementum"
            elif engine == "Elementum" and not self.is_engine_alive("Elementum"):
                if Config.elementum_auto_heal() and self.try_recover_elementum():
                    return "Elementum"
                for _ in range(4):
                    xbmc.sleep(500)
                    if self.is_engine_alive("Elementum"):
                        return "Elementum"
                log("Elementum unreachable during preflight", level="warning")

        return engine

    def _to_engine_url(self, uri, stream):
        encoded = quote(uri, safe="")
        file_idx = stream.get("fileIdx") if isinstance(stream, dict) else None
        stream_title = (stream.get("title") or stream.get("name") or "").split("\n")[0].strip() if isinstance(stream, dict) else ""
        active = self.get_active_engine()

        if active == "TorrServer":
            return self.resolve_torrserver_stream(uri, file_idx, stream_title)
        elif active == "Elementum":
            base = f"plugin://plugin.video.elementum/play?uri={encoded}"
            if file_idx is not None:
                base += f"&oindex={file_idx}"
            return base
        elif active == "Torrest":
            if uri.startswith("magnet:"):
                base = f"plugin://plugin.video.torrest/play_magnet?magnet={encoded}"
            else:
                base = f"plugin://plugin.video.torrest/play_url?url={encoded}"
            if file_idx is not None:
                base += f"&file_id={file_idx}"
            return base
        return uri

    def _enrich_magnet(self, magnet_uri, stream=None):
        if not magnet_uri or not magnet_uri.startswith("magnet:"):
            return magnet_uri

        lower_mag = magnet_uri.lower()
        extra_trackers = []
        if isinstance(stream, dict):
            sources = stream.get("sources", []) or []
            for s in sources:
                if isinstance(s, str):
                    if s.startswith("tracker:"):
                        extra_trackers.append(s[len("tracker:"):].strip())
                    elif s.startswith("http://") or s.startswith("https://") or s.startswith("udp://"):
                        extra_trackers.append(s.strip())
            for tr in (stream.get("trackers", []) or []):
                if isinstance(tr, str) and tr.strip():
                    extra_trackers.append(tr.strip())

        all_candidates = extra_trackers + TRACKERS
        for tr in all_candidates:
            if not tr:
                continue
            quoted_tr = quote(tr, safe="")
            if quoted_tr.lower() not in lower_mag and tr.lower() not in lower_mag:
                magnet_uri += f"&tr={quoted_tr}"
                lower_mag += f"&tr={quoted_tr.lower()}"

        return magnet_uri

    def _build_magnet(self, info_hash, stream):
        title = stream.get("title", "") or stream.get("name", "Unknown") if isinstance(stream, dict) else "Unknown"
        dn = re.sub(r"\[.*?\]", "", title.split("\n")[0]).strip()
        dn = re.sub(r"\s+", ".", dn)[:100]

        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(dn, safe='')}"
        return self._enrich_magnet(magnet, stream)

    # ── Sorting & Filtering ────────────────────────────────
    def filter_by_title_match(self, streams, title="", original_title="", media_type="movie", season=None, episode=None):
        """
        Filters out irrelevant torrents (e.g. DHT search false positives like 'Boston Blue' for 'Bluey').
        Stremio addon streams (which query exact IMDB IDs) are always trusted.
        """
        if not streams or (not title and not original_title):
            return streams

        candidates = [t for t in [title, original_title] if t]

        filtered = []
        for s in streams:
            addon = s.get("_addon", "")
            # If stream is from Stremio addons with exact IMDB ID, preserve it
            if addon and addon not in ("Apibay", "Bitsearch", "SolidTorrents", "Apibay Trending", "Unknown"):
                filtered.append(s)
                continue

            stream_title = s.get("title", "") or s.get("name", "")
            if not stream_title:
                continue

            matched = any(
                self._is_title_match(stream_title, expected, media_type, season, episode)
                for expected in candidates
            )
            if matched:
                filtered.append(s)

        # If strict filtering filtered everything out, keep non-DHT streams if available
        if not filtered:
            fallback = [s for s in streams if s.get("_addon") not in ("Apibay", "Bitsearch", "SolidTorrents", "Apibay Trending")]
            return fallback if fallback else streams

        return filtered

    def _is_title_match(self, torrent_title, expected_title, media_type="movie", season=None, episode=None):
        if not expected_title or not torrent_title:
            return True

        clean_torrent = re.sub(r"[\._\-\+\[\]\(\)\:\,]+", " ", torrent_title).lower()
        clean_expected = re.sub(r"[\._\-\+\[\]\(\)\:\,]+", " ", expected_title).lower()

        base_name = re.sub(r"\bs\d+e\d+\b", "", clean_expected, flags=re.IGNORECASE)
        base_name = re.sub(r"\b\d+x\d+\b", "", base_name, flags=re.IGNORECASE)
        base_name = re.sub(r"\b\d{4}\b", "", base_name)
        base_name = re.sub(r"\s+", " ", base_name).strip()

        if not base_name:
            base_name = clean_expected.strip()

        words = [re.escape(w) for w in base_name.split() if len(w) > 0]
        if not words:
            return True

        pattern = r"\b" + r"[\s\._\-]+".join(words) + r"\b"
        if not re.search(pattern, clean_torrent, re.IGNORECASE):
            return False

        if media_type == "series" and season is not None and episode is not None:
            try:
                s_int = int(season)
                e_int = int(episode)
                ep_patterns = [
                    rf"\bs0*{s_int}\s*e0*{e_int}\b",
                    rf"\b0*{s_int}x0*{e_int}\b",
                    rf"\bseason\s*0*{s_int}\s*episode\s*0*{e_int}\b",
                    rf"\bs0*{s_int}\b(?!\s*e\d+)",
                    rf"\bseason\s*0*{s_int}\b",
                    rf"\btemporada\s*0*{s_int}\b",
                    r"\bcomplete\s*(?:series|tv|boxset|season)?\b",
                    r"\ball\s*seasons\b",
                    r"\bseasons?\s*\d+(?:\s*(?:-|to|\sand\s|,|\s)\s*\d+)*\b",
                    r"\bs\d+\s*-\s*s\d+\b"
                ]
                has_ep = any(re.search(p, clean_torrent, re.IGNORECASE) for p in ep_patterns)
                if not has_ep:
                    return False
            except (ValueError, TypeError):
                pass

        return True

    def filter_by_quality(self, streams):
        preferred = Config.torrent_quality()
        if preferred == "Any":
            return streams
        pattern = QUALITY_PATTERNS.get(preferred)
        if not pattern:
            return streams
        filtered = [
            s for s in streams
            if pattern.search(s.get("title", "") or s.get("name", ""))
        ]
        return filtered if filtered else streams

    def filter_spanish(self, streams):
        """Filter/tag streams based on Spanish language preference."""
        mode = Config.spanish_filter_mode()
        if mode == "off":
            return streams

        for s in streams:
            title = s.get("title", "") or s.get("name", "")
            s["_spanish"] = detect_spanish(title)

        if mode == "only":
            variant_pref = Config.spanish_variant()
            filtered = []
            for s in streams:
                info = s.get("_spanish", {})
                if not info.get("is_spanish"):
                    continue
                if variant_pref == "castellano" and info.get("variant") not in ("CAST", "ESP"):
                    continue
                if variant_pref == "latino" and info.get("variant") not in ("LAT", "LAT-MX"):
                    continue
                if variant_pref == "dual" and info.get("variant") != "DUAL":
                    continue
                filtered.append(s)
            return filtered if filtered else streams

        return streams

    def sort_streams(self, streams):
        """
        Intelligent stream sorting:
        1. Real-Debrid cached streams always prioritized (+10,000,000)
        2. Healthy swarms (seeds >= 3) prioritized.
        3. Dead streams (0 seeds, un-cached) heavily penalized (-500,000).
        4. Spanish boost applied to healthy streams (seeds >= 3 or RD cached).
        5. Ties resolved by user preference (Seeds, Quality, Size).
        """
        sort_by = Config.torrent_sort()
        spanish_on = Config.spanish_boost() and Config.spanish_filter_mode() != "off"

        def _sort_key(s):
            is_rd = bool(s.get("_rd_cached") and Config.rd_priority())
            seeds = self._extract_seeds(s)

            # Base health score
            if is_rd:
                health_score = 10000000
            elif seeds <= 0:
                health_score = -500000  # Dead swarm penalty
            elif seeds < 3:
                health_score = -100000 + (seeds * 100)  # Unhealthy swarm penalty
            else:
                health_score = min(seeds, 500) * 100  # Up to 50,000 points (healthy swarms prioritize speed & stability)

            # Single-file torrent bonus (far more reliable on P2P engines than multi-file season packs)
            file_bonus = 0
            if s.get("fileIdx") is None:
                file_bonus = 1000

            # Spanish boost (only granted to healthy streams or RD cached)
            esp_boost = 0
            if spanish_on and (is_rd or seeds >= 3):
                esp_score = get_spanish_boost(s)
                if esp_score >= 50:
                    esp_boost = 50000 + (esp_score * 100)

            # Preference score
            pref_score = 0
            if sort_by == "Seeds":
                pref_score = seeds * 50
            elif sort_by == "Quality":
                pref_score = self._quality_score(s) * 300
            elif sort_by == "Size":
                pref_score = int(self._extract_size_gb(s) * 100)

            return health_score + file_bonus + esp_boost + pref_score

        return sorted(streams, key=_sort_key, reverse=True)

    def _extract_seeds(self, s):
        seeds = s.get("seeds")
        if seeds is None:
            seeds = s.get("seeders") or s.get("seed")
        if seeds is not None:
            try:
                return int(seeds)
            except (ValueError, TypeError):
                pass

        text = " ".join([
            str(s.get("title") or ""),
            str(s.get("name") or ""),
            str(s.get("description") or "")
        ])
        match = re.search(r"(?:👤|\bseeds?\s*[:=]?\s*|\bseeders?\s*[:=]?\s*|\[s:\s*)\s*(\d+)", text, re.IGNORECASE)
        if match:
            try:
                return int(match.group(1))
            except (ValueError, TypeError):
                pass
        return 0

    def _quality_score(self, s):
        title = (s.get("title", "") or s.get("name", "")).lower()
        if "2160p" in title or "4k" in title:
            return 4
        if "1080p" in title:
            return 3
        if "720p" in title:
            return 2
        if "480p" in title:
            return 1
        return 0

    def _extract_size_gb(self, s):
        title = s.get("title", "") or s.get("name", "")
        match = re.search(r"([\d.]+)\s*GB", title, re.IGNORECASE)
        if match:
            return float(match.group(1))
        match = re.search(r"([\d.]+)\s*MB", title, re.IGNORECASE)
        if match:
            return float(match.group(1)) / 1024
        return 0

    # ── Display labels ─────────────────────────────────────
    def get_quality_label(self, stream):
        title = (stream.get("title", "") or stream.get("name", "")).lower()
        if "2160p" in title or "4k" in title:
            return "[COLOR gold]4K[/COLOR]"
        if "1080p" in title:
            return "[COLOR lime]1080p[/COLOR]"
        if "720p" in title:
            return "[COLOR cyan]720p[/COLOR]"
        if "480p" in title:
            return "[COLOR grey]480p[/COLOR]"
        return ""

    def get_seeds_label(self, stream):
        seeds = self._extract_seeds(stream)
        if seeds > 50:
            return f"[COLOR lime]👤 {seeds}[/COLOR]"
        elif seeds > 5:
            return f"[COLOR yellow]👤 {seeds}[/COLOR]"
        elif seeds > 0:
            return f"[COLOR orange]👤 {seeds}[/COLOR]"
        return "[COLOR red]👤 0[/COLOR]"

    def get_size_label(self, stream):
        title = stream.get("title", "") or stream.get("name", "")
        match = re.search(r"([\d.]+\s*(?:GB|MB))", title, re.IGNORECASE)
        return match.group(1) if match else ""

    def get_rd_label(self, stream):
        if stream.get("_rd_cached"):
            return "[COLOR magenta][RD+][/COLOR]"
        return ""

    def get_spanish_tag(self, stream):
        return get_spanish_label(stream)
