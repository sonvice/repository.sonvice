# -*- coding: utf-8 -*-
"""
Background Stream Downloader for Stremio4Kodi.
Handles downloading of direct HTTP / Debrid streams to user-specified storage paths.
"""
import os
import re
import threading
import urllib.request

from resources.lib.config import Config
from resources.lib.logger import log

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

_active_downloads = set()


def start_direct_download(stream_url, title="video", custom_path=None):
    """
    Spawns a background thread to download a direct HTTP/Debrid stream
    into the configured download directory.
    """
    if not Config.download_playback_enabled() or not Config.download_direct_streams():
        return

    if not stream_url or not stream_url.startswith("http"):
        return

    target_dir = (custom_path or Config.download_playback_path() or "").strip()
    if not target_dir:
        return

    if xbmcvfs:
        target_dir = xbmcvfs.translatePath(target_dir)

    try:
        os.makedirs(target_dir, exist_ok=True)
    except Exception as e:
        log(f"Cannot create download directory {target_dir}: {e}", level="warning")
        return

    # Clean filename
    clean_title = re.sub(r'[/\\?%*:|"<>]', '.', title or "video").strip()
    if not any(clean_title.lower().endswith(ext) for ext in (".mkv", ".mp4", ".avi", ".ts", ".webm")):
        clean_title += ".mkv"

    final_path = os.path.join(target_dir, clean_title)
    part_path = final_path + ".part"

    if os.path.exists(final_path) and os.path.getsize(final_path) > 1024 * 1024:
        log(f"Direct stream download skipped: file already exists ({final_path})", level="info")
        return

    if final_path in _active_downloads:
        log(f"Direct stream download already in progress for {clean_title}", level="info")
        return

    def _worker():
        _active_downloads.add(final_path)
        log(f"Starting direct stream download: {clean_title} -> {part_path}", level="info")

        if xbmcgui:
            try:
                xbmcgui.Dialog().notification(
                    "Stremio4Kodi",
                    f"Descarga en curso: {clean_title[:32]}",
                    xbmcgui.NOTIFICATION_INFO,
                    3000
                )
            except Exception:
                pass

        req = urllib.request.Request(
            stream_url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0"}
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp, open(part_path, "wb") as out_file:
                chunk_size = 256 * 1024  # 256 KB
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    out_file.write(chunk)

            if os.path.exists(part_path):
                if os.path.exists(final_path):
                    os.remove(final_path)
                os.rename(part_path, final_path)
                log(f"Direct stream download finished successfully: {final_path}", level="info")
                if xbmcgui:
                    try:
                        xbmcgui.Dialog().notification(
                            "Stremio4Kodi",
                            f"Descarga completa: {clean_title[:32]}",
                            xbmcgui.NOTIFICATION_INFO,
                            4000
                        )
                    except Exception:
                        pass
        except Exception as err:
            log(f"Direct stream download failed for {clean_title}: {err}", level="warning")
            if not Config.download_playback_keep():
                try:
                    if os.path.exists(part_path):
                        os.remove(part_path)
                except Exception:
                    pass
        finally:
            _active_downloads.discard(final_path)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()
