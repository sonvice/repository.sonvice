# -*- coding: utf-8 -*-
"""
OpenSubtitles v3 Subtitle Provider for Kodi.
Provides free, fast, zero-credential subtitle searches and downloads
from OpenSubtitles v3 (Stremio CDN) for movies and TV series.
"""
import os
import re
import sys
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

SUBTITLE_PROVIDERS = [
    "https://opensubtitles-v3.strem.io",
    "https://opensubtitles.strem.io",
]

LANG_META = {
    "spa": {"name": "Español (Castellano)", "flag": "🇪🇸"},
    "es":  {"name": "Español (Castellano)", "flag": "🇪🇸"},
    "spl": {"name": "Español (Latino)",     "flag": "🇲🇽"},
    "lat": {"name": "Español (Latino)",     "flag": "🇲🇽"},
    "eng": {"name": "Inglés (English)",     "flag": "🇬🇧"},
    "en":  {"name": "Inglés (English)",     "flag": "🇬🇧"},
    "por": {"name": "Portugués",            "flag": "🇵🇹"},
    "pt":  {"name": "Portugués",            "flag": "🇵🇹"},
    "pob": {"name": "Portugués (Brasil)",   "flag": "🇧🇷"},
    "fre": {"name": "Francés (Français)",   "flag": "🇫🇷"},
    "fra": {"name": "Francés (Français)",   "flag": "🇫🇷"},
    "fr":  {"name": "Francés (Français)",   "flag": "🇫🇷"},
    "ger": {"name": "Alemán (Deutsch)",     "flag": "🇩🇪"},
    "deu": {"name": "Alemán (Deutsch)",     "flag": "🇩🇪"},
    "de":  {"name": "Alemán (Deutsch)",     "flag": "🇩🇪"},
    "ita": {"name": "Italiano",             "flag": "🇮🇹"},
    "it":  {"name": "Italiano",             "flag": "🇮🇹"},
}

def log(msg, level="info"):
    kodi_lvl = xbmc.LOGINFO if level == "info" else xbmc.LOGDEBUG
    xbmc.log(f"[service.subtitles.opensubtitles-stremio] {msg}", kodi_lvl)


def get_current_media_info():
    info = {
        "imdb_id": None,
        "media_type": "movie",
        "season": None,
        "episode": None,
        "title": "",
        "year": ""
    }

    try:
        window = xbmcgui.Window(10000)
        cached_imdb = window.getProperty("stremio4kodi.current_imdb")
        if cached_imdb:
            info["imdb_id"] = cached_imdb
            info["media_type"] = window.getProperty("stremio4kodi.current_type") or "movie"
            info["season"] = window.getProperty("stremio4kodi.current_season") or None
            info["episode"] = window.getProperty("stremio4kodi.current_episode") or None
            info["title"] = window.getProperty("stremio4kodi.current_title") or ""
            return info
    except Exception:
        pass

    try:
        imdb_label = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
        if imdb_label:
            cleaned = imdb_label.strip()
            if cleaned.startswith("tt"):
                info["imdb_id"] = cleaned
            elif cleaned.isdigit():
                info["imdb_id"] = f"tt{cleaned}"
    except Exception:
        pass

    try:
        tv_show = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        title = xbmc.getInfoLabel("VideoPlayer.Title")
        season = xbmc.getInfoLabel("VideoPlayer.Season")
        episode = xbmc.getInfoLabel("VideoPlayer.Episode")
        year = xbmc.getInfoLabel("VideoPlayer.Year")

        if tv_show:
            info["media_type"] = "series"
            info["title"] = tv_show
            info["season"] = season if season and season.isdigit() else None
            info["episode"] = episode if episode and episode.isdigit() else None
        else:
            info["media_type"] = "movie"
            info["title"] = title

        info["year"] = year
    except Exception:
        pass

    if not info["imdb_id"] and info["title"]:
        resolved = resolve_imdb_by_title(info["title"], info["media_type"], info["year"])
        if resolved:
            info["imdb_id"] = resolved

    return info


def resolve_imdb_by_title(title, media_type="movie", year=None):
    if not title:
        return None
    try:
        c_type = "series" if media_type in ("series", "tv") else "movie"
        url = f"https://v3-cinemeta.strem.io/catalog/{c_type}/top/search={urllib.parse.quote(title)}.json"
        req = urllib.request.Request(url, headers={"User-Agent": "OpenSubtitlesStremio/1.0"})
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            metas = data.get("metas", [])
            if metas:
                if year:
                    for m in metas:
                        if str(year) in str(m.get("releaseInfo", "")):
                            return m.get("imdb_id") or m.get("id")
                return metas[0].get("imdb_id") or metas[0].get("id")
    except Exception as e:
        log(f"Error resolving IMDb ID for '{title}': {e}", level="debug")
    return None


def fetch_subtitles(imdb_id, media_type="movie", season=None, episode=None, timeout=6):
    if not imdb_id:
        return []

    base_imdb = imdb_id.split(":")[0] if ":" in imdb_id else imdb_id
    target_id = base_imdb
    if media_type in ("series", "tv") and season and episode:
        target_id = f"{base_imdb}:{season}:{episode}"
    elif ":" in imdb_id:
        target_id = imdb_id

    results = []
    seen_urls = set()

    for base_url in SUBTITLE_PROVIDERS:
        try:
            endpoint = f"{base_url}/subtitles/{media_type}/{target_id}.json"
            req = urllib.request.Request(
                endpoint,
                headers={"User-Agent": "OpenSubtitlesStremio/1.0", "Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                subs = data.get("subtitles", [])
                for s in subs:
                    url = s.get("url", "")
                    if not url or url in seen_urls:
                        continue
                    seen_urls.add(url)

                    lang_code = s.get("lang", "").lower()
                    meta = LANG_META.get(lang_code, {
                        "name": lang_code.upper() if lang_code else "Desconocido",
                        "flag": "🌐"
                    })
                    fn = s.get("subtitleFileName") or s.get("movieReleaseName") or f"{lang_code}_{s.get('id', 'sub')}.srt"

                    results.append({
                        "id": str(s.get("id", len(results))),
                        "lang": lang_code,
                        "lang_name": meta["name"],
                        "flag": meta["flag"],
                        "filename": fn,
                        "url": url,
                    })

                if results:
                    break
        except Exception as e:
            log(f"Error fetching from {base_url}: {e}", level="debug")

    def _rank(item):
        lang = item.get("lang", "").lower()
        if lang in ("spa", "es", "spl", "lat"):
            return 0
        if lang in ("eng", "en"):
            return 1
        return 2

    results.sort(key=_rank)
    return results


def download_sub(url, filename):
    try:
        temp_dir = xbmcvfs.translatePath("special://temp/subtitles/")
    except Exception:
        temp_dir = os.path.join("/tmp", "stremio_subtitles")
    os.makedirs(temp_dir, exist_ok=True)

    clean_fn = re.sub(r'[\\/*?:"<>|]', "", filename or "subtitle.srt")
    if not clean_fn.endswith(".srt"):
        clean_fn += ".srt"

    local_path = os.path.join(temp_dir, clean_fn)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "*/*"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read()
        with open(local_path, "wb") as f:
            f.write(content)
        log(f"Downloaded sub to {local_path} ({len(content)} bytes)")
        return local_path
    except Exception as e:
        log(f"Download failed: {e}", level="error")
        return None


def handle_search(handle, params):
    info = get_current_media_info()
    imdb_id = info["imdb_id"]
    media_type = info["media_type"]
    season = info["season"]
    episode = info["episode"]

    if not imdb_id:
        xbmcplugin.endOfDirectory(handle)
        return

    subs = fetch_subtitles(imdb_id, media_type, season, episode)
    for s in subs:
        label = f"{s['flag']} {s['lang_name']}"
        label2 = s["filename"]

        li = xbmcgui.ListItem(label=label, label2=label2)
        li.setProperty("sync", "true")
        is_hi = "sdh" in label2.lower() or "hi" in label2.lower()
        li.setProperty("hearing_imp", "true" if is_hi else "false")
        li.setArt({"icon": "5"})

        download_url = f"{sys.argv[0]}?action=download&sub_url={urllib.parse.quote_plus(s['url'])}&filename={urllib.parse.quote_plus(label2)}"
        xbmcplugin.addDirectoryItem(handle=handle, url=download_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def handle_manualsearch(handle, params):
    searchstring = params.get("searchstring", "")
    if not searchstring:
        kb = xbmc.Keyboard("", "Buscar subtítulos (Título o IMDb tt...)")
        kb.doModal()
        if kb.isConfirmed():
            searchstring = kb.getText()
        else:
            xbmcplugin.endOfDirectory(handle)
            return

    if not searchstring:
        xbmcplugin.endOfDirectory(handle)
        return

    imdb_id = None
    media_type = "movie"
    season = None
    episode = None

    if searchstring.strip().startswith("tt"):
        imdb_id = searchstring.strip()
    else:
        se_match = re.search(r's(\d+)\s*e(\d+)', searchstring, re.IGNORECASE)
        if se_match:
            media_type = "series"
            season = se_match.group(1)
            episode = se_match.group(2)
            title_clean = re.sub(r's\d+\s*e\d+.*', '', searchstring, flags=re.IGNORECASE).strip()
            imdb_id = resolve_imdb_by_title(title_clean, "series")
        else:
            imdb_id = resolve_imdb_by_title(searchstring, "movie")
            if not imdb_id:
                imdb_id = resolve_imdb_by_title(searchstring, "series")
                if imdb_id:
                    media_type = "series"

    if not imdb_id:
        xbmcplugin.endOfDirectory(handle)
        return

    subs = fetch_subtitles(imdb_id, media_type, season, episode)
    for s in subs:
        label = f"{s['flag']} {s['lang_name']}"
        label2 = s["filename"]

        li = xbmcgui.ListItem(label=label, label2=label2)
        li.setProperty("sync", "true")
        is_hi = "sdh" in label2.lower() or "hi" in label2.lower()
        li.setProperty("hearing_imp", "true" if is_hi else "false")
        li.setArt({"icon": "5"})

        download_url = f"{sys.argv[0]}?action=download&sub_url={urllib.parse.quote_plus(s['url'])}&filename={urllib.parse.quote_plus(label2)}"
        xbmcplugin.addDirectoryItem(handle=handle, url=download_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def handle_download(handle, params):
    sub_url = urllib.parse.unquote_plus(params.get("sub_url", ""))
    filename = urllib.parse.unquote_plus(params.get("filename", "subtitle.srt"))

    if not sub_url:
        xbmcplugin.endOfDirectory(handle)
        return

    local_path = download_sub(sub_url, filename)
    if local_path and os.path.exists(local_path):
        li = xbmcgui.ListItem(label=local_path)
        xbmcplugin.addDirectoryItem(handle=handle, url=local_path, listitem=li, isFolder=False)
        try:
            player = xbmc.Player()
            if player.isPlaying():
                player.setSubtitles(local_path)
                player.showSubtitles(True)
        except Exception:
            pass

    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
        qs = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
        params = {k: v[0] for k, v in urllib.parse.parse_qs(qs).items()}
        action = params.get("action", "")

        if action == "search":
            handle_search(handle, params)
        elif action == "manualsearch":
            handle_manualsearch(handle, params)
        elif action == "download":
            handle_download(handle, params)
        else:
            xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        log(f"Error in main: {e}", level="error")
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            try:
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
            except Exception:
                pass
