# -*- coding: utf-8 -*-
"""
Router — URL dispatcher v3.2.
v3.2: AceStream support (replaces Live TV), fixed platform duplication,
      manual acestream hash/URL input.
"""
import os
import sys
import re
import json
import threading
from urllib.parse import parse_qs, urlencode, quote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib.stremio import StremioClient
from resources.lib.torrent import TorrentResolver
from resources.lib.debrid import RealDebrid
from resources.lib.trakt import Trakt
from resources.lib.cache import CacheDB
from resources.lib.config import Config
from resources.lib.logger import log
from resources.lib import ui
from resources.lib.dht_search import BitsearchClient
from resources.lib.tmdb import TMDBClient
from resources.lib.rottentomatoes import RottenTomatoesClient


class Router:
    def __init__(self):
        self.stremio = StremioClient()
        self.resolver = TorrentResolver()
        self.rd = RealDebrid()
        self.trakt = Trakt()
        self.cache = CacheDB()
        self.bitsearch = BitsearchClient()
        self.tmdb = TMDBClient()
        self.rt = RottenTomatoesClient()

    def dispatch(self, argv):
        self.base_url = argv[0]
        self.handle = int(argv[1])
        self.params = {}

        if len(argv) > 2 and argv[2]:
            self.params = {k: v[0] for k, v in parse_qs(argv[2].lstrip("?")).items()}

        action = self.params.get("action", "")
        log(f"Dispatch: {action} | {self.params}", level="debug")

        routes = {
            "":                self._main_menu,
            "movies":          self._movies,
            "series":          self._series,
            "catalog":         self._catalog,
            "genres":          self._genres,
            "genre_list":      self._genre_list,
            "seasons":         self._seasons,
            "episodes":        self._episodes,
            "streams":         self._streams,
            "play":            self._play,
            "search":          self._search,
            "search_results":  self._search_results,
            "dht_search":      self._dht_search,
            "raw_dht_search":  self._raw_dht_search,
            "trending":        self._trending,
            "manual_torrent":  self._manual_torrent,
            "favorites":       self._favorites,
            "toggle_favorite": self._toggle_favorite,
            "history":         self._history,
            "continue_watching": self._continue_watching,
            "trakt_menu":      self._trakt_menu,
            "trakt_auth":      self._trakt_auth,
            "trakt_watchlist": self._trakt_watchlist,
            "trakt_recommendations": self._trakt_recommendations,
            "trakt_trending":  self._trakt_trending,
            "trakt_add":       self._trakt_add,
            "trakt_remove":    self._trakt_remove,
            "clear_cache":     self._clear_cache,
            "clear_history":   self._clear_history,
            "settings":        self._settings,
            # v3 routes
            "platforms":           self._platforms,
            "platform_type":       self._platform_type,
            "platform_catalog":    self._platform_catalog,
            # v3.2: AceStream (replaces livetv)
            "acestream":           self._acestream,
            "acestream_group":     self._acestream_group,
            "acestream_play":      self._acestream_play,
            "acestream_refresh":   self._acestream_refresh,
            "acestream_all":       self._acestream_all,
            "acestream_manual":    self._acestream_manual,
            "vpn_toggle":          self._vpn_toggle,
            # v3.3: TMDB Routes
            "tmdb_movies":         self._tmdb_movies,
            "tmdb_series":         self._tmdb_series,
            "tmdb_catalog":        self._tmdb_catalog,
            "tmdb_genres":         self._tmdb_genres,
            "tmdb_seasons":        self._tmdb_seasons,
            "tmdb_episodes":       self._tmdb_episodes,
            "catalog_list":        self._catalog_list_route,
            "search_subtitles":    self._search_subtitles,
        }

        handler = routes.get(action, self._main_menu)
        try:
            handler()
        except Exception as e:
            log(f"Error [{action}]: {e}", level="error")
            import traceback
            log(traceback.format_exc(), level="error")
            ui.show_notification(str(e), icon=xbmcgui.NOTIFICATION_ERROR)

    # ══════════════════════════════════════════════════════
    #  MAIN MENU
    # ══════════════════════════════════════════════════════
    def _main_menu(self):
        items = [
            ("Peliculas",           "movies",             "DefaultMovies.png"),
            ("Series",              "series",             "DefaultTVShows.png"),
            ("Buscador",            "dht_search",         "DefaultAddonsSearch.png"),
            ("Trending Torrents",   "trending",           "DefaultTVShows.png"),
            ("Generos",             "genres",             "DefaultGenre.png"),
        ]

        # v3: Streaming Platforms
        try:
            if Config.streaming_catalogs_enabled():
                items.append(("Plataformas (Netflix, HBO, Disney+...)", "platforms", "DefaultStudios.png"))
        except Exception:
            pass

        # v3.2: AceStream (replaces Live TV)
        try:
            if Config.acestream_enabled():
                items.append(("AceStream / TV en Directo", "acestream", "DefaultPVRTVChannels.png"))
        except Exception:
            pass

        items.extend([
            ("Seguir viendo",       "continue_watching",  "DefaultInProgressShows.png"),
            ("Favoritos",           "favorites",          "DefaultFavourites.png"),
            ("Historial",           "history",            "DefaultRecentlyAddedEpisodes.png"),
            ("Pegar Magnet/Torrent","manual_torrent",     "DefaultNetwork.png"),
        ])

        if Config.trakt_enabled():
            items.append(("Trakt", "trakt_menu", "DefaultAddonProgram.png"))

        items.append(("Ajustes", "settings", "DefaultAddonProgram.png"))

        for label, action, icon in items:
            ui.add_directory_item(
                handle=self.handle, label=label, action=action,
                base_url=self.base_url, icon=icon,
            )
        ui.end_directory(self.handle, content_type="")

    # ══════════════════════════════════════════════════════
    #  MOVIES / SERIES
    # ══════════════════════════════════════════════════════
    # ══════════════════════════════════════════════════════
    #  MOVIES / SERIES / TMDB
    # ══════════════════════════════════════════════════════
    def _movies(self):
        if Config.tmdb_enabled():
            self._tmdb_movies()
        else:
            self._list_catalogs("movie")

    def _series(self):
        if Config.tmdb_enabled():
            self._tmdb_series()
        else:
            self._list_catalogs("series")

    def _tmdb_movies(self):
        items = [
            ("Tendencias (Hoy / Semana)", "trending", "DefaultRecentlyAddedMovies.png"),
            ("Lo mas popular", "popular", "DefaultMovies.png"),
            ("En cartelera (Estrenos Cine)", "now_playing", "DefaultMovies.png"),
            ("Mejor puntuadas", "top_rated", "DefaultMovies.png"),
            ("Top 100 Ultimos Anos", "top_100", "DefaultYear.png"),
            ("Categorias / Generos", "genres", "DefaultGenre.png"),
        ]
        for label, section, icon in items:
            action = "tmdb_genres" if section == "genres" else "tmdb_catalog"
            ui.add_directory_item(
                handle=self.handle, label=label, action=action,
                base_url=self.base_url, icon=icon, media_type="movie",
                section=section
            )
        
        ui.add_directory_item(
            handle=self.handle, label="[B]Catalogos Stremio (Cinemeta / Addons)[/B]", action="catalog_list",
            base_url=self.base_url, icon="DefaultFolder.png", media_type="movie"
        )
        ui.end_directory(self.handle)

    def _tmdb_series(self):
        items = [
            ("Tendencias (Hoy / Semana)", "trending", "DefaultRecentlyAddedEpisodes.png"),
            ("Lo mas popular", "popular", "DefaultTVShows.png"),
            ("En emision / Al aire", "now_playing", "DefaultTVShows.png"),
            ("Mejor puntuadas", "top_rated", "DefaultTVShows.png"),
            ("Top 100 Ultimos Anos", "top_100", "DefaultYear.png"),
            ("Categorias / Generos", "genres", "DefaultGenre.png"),
        ]
        for label, section, icon in items:
            action = "tmdb_genres" if section == "genres" else "tmdb_catalog"
            ui.add_directory_item(
                handle=self.handle, label=label, action=action,
                base_url=self.base_url, icon=icon, media_type="series",
                section=section
            )
        
        ui.add_directory_item(
            handle=self.handle, label="[B]Catalogos Stremio (Cinemeta / Addons)[/B]", action="catalog_list",
            base_url=self.base_url, icon="DefaultFolder.png", media_type="series"
        )
        ui.end_directory(self.handle)

    def _tmdb_catalog(self):
        media_type = self.params.get("media_type", "movie")
        section = self.params.get("section", "popular")
        page = int(self.params.get("page", "1"))
        genre_id = self.params.get("genre_id", "")

        tmdb_media = "movie" if media_type == "movie" else "tv"
        items = []
        total_pages = 1

        try:
            if section == "trending":
                items, total_pages = self.tmdb.get_trending(tmdb_media, time_window="week", page=page)
            elif section == "popular":
                items, total_pages = self.tmdb.get_popular(tmdb_media, page=page)
            elif section == "now_playing":
                items, total_pages = self.tmdb.get_now_playing(tmdb_media, page=page)
            elif section == "top_rated":
                items, total_pages = self.tmdb.get_top_rated(tmdb_media, page=page)
            elif section == "top_100":
                items, total_pages = self.tmdb.get_top_100_recent(tmdb_media, page=page)
            elif section == "genre":
                items, total_pages = self.tmdb.discover_by_genre(tmdb_media, genre_id, page=page)
            else:
                items, total_pages = self.tmdb.get_popular(tmdb_media, page=page)
        except Exception as e:
            log(f"TMDB catalog error [{section}]: {e}", level="error")

        # FALLBACK TO STREMIO CATALOGS IF TMDB FAILS OR IS EMPTY
        if not items:
            log("TMDB catalog empty or failed. Falling back to Stremio Cinemeta catalogs", level="info")

            cat_id = "imdbRating" if section in ("now_playing", "top_100", "top_rated") else "top"
            extra = f"skip={(page - 1) * 25}" if page > 1 else ""

            for addon_url in Config.stremio_addon_urls():
                try:
                    c_items = self.stremio.get_catalog(addon_url, media_type, cat_id, extra)
                    if c_items:
                        items.extend(c_items)
                        break
                except Exception as e:
                    log(f"Fallback Stremio catalog error [{addon_url}]: {e}", level="debug")

        if not items:
            try:
                c_items = self.stremio.get_catalog("https://v3-cinemeta.strem.io", media_type, "top", "")
                if c_items:
                    items.extend(c_items)
            except Exception as e:
                log(f"Direct Cinemeta fallback error: {e}", level="debug")

        if not items:
            ui.show_notification("No se encontraron elementos.")
            ui.end_directory(self.handle)
            return

        items = self.stremio.dedup_items(items) if hasattr(self.stremio, "dedup_items") else items
        self._render_item_list(items, media_type)

        if items and page < total_pages and page < 50:
            kwargs = {
                "handle": self.handle, "label": "[B]>> Siguiente pagina[/B]",
                "action": "tmdb_catalog", "base_url": self.base_url,
                "media_type": media_type, "section": section, "page": str(page + 1)
            }
            if genre_id:
                kwargs["genre_id"] = genre_id
            ui.add_directory_item(**kwargs)

        content = "movies" if media_type == "movie" else "tvshows"
        ui.end_directory(self.handle, content_type=content)

    def _tmdb_genres(self):
        media_type = self.params.get("media_type", "movie")
        tmdb_media = "movie" if media_type == "movie" else "tv"
        genres = []
        try:
            genres = self.tmdb.get_genres(tmdb_media)
        except Exception as e:
            log(f"TMDB genres error: {e}", level="error")

        if not genres:
            log("TMDB genres failed. Falling back to Stremio genres", level="info")
            genres_list = self.stremio.get_genres(media_type)
            for gname in genres_list:
                ui.add_directory_item(
                    handle=self.handle, label=gname, action="genre_list",
                    base_url=self.base_url, icon="DefaultGenre.png",
                    media_type=media_type, genre=gname
                )
            ui.end_directory(self.handle)
            return

        for g in genres:
            gid = str(g.get("id"))
            gname = g.get("name")
            ui.add_directory_item(
                handle=self.handle, label=gname, action="tmdb_catalog",
                base_url=self.base_url, icon="DefaultGenre.png",
                media_type=media_type, section="genre", genre_id=gid
            )
        ui.end_directory(self.handle)

    def _tmdb_seasons(self):
        tmdb_id = self.params.get("tmdb_id", "")
        title = self.params.get("title", "")
        original_title = self.params.get("original_title", title)
        imdb_id = self.params.get("imdb_id", "")

        if not tmdb_id and imdb_id:
            if imdb_id.startswith("tmdb:"):
                tmdb_id = imdb_id.split("tmdb:")[1]
            elif imdb_id.startswith("tt"):
                try:
                    found_id, _ = self.tmdb.find_by_imdb_id(imdb_id)
                    if found_id:
                        tmdb_id = found_id
                except Exception as e:
                    log(f"TMDB resolve error: {e}", level="debug")

        seasons = []
        show_info = None
        if tmdb_id:
            try:
                seasons, show_info = self.tmdb.get_tv_seasons(tmdb_id)
            except Exception as e:
                log(f"TMDB seasons error: {e}", level="error")

        if not seasons and imdb_id:
            log("TMDB seasons failed. Falling back to Stremio seasons", level="info")
            self._seasons()
            return

        if not seasons:
            ui.show_notification("No se pudieron cargar las temporadas.")
            ui.end_directory(self.handle)
            return

        # Ensure we have the canonical tt... IMDb ID for Stremio addons
        if (not imdb_id or imdb_id.startswith("tmdb:")) and show_info:
            imdb_id = show_info.get("imdb_id", "")
        if (not imdb_id or imdb_id.startswith("tmdb:")) and tmdb_id:
            try:
                ext_id = self.tmdb.get_external_ids("tv", tmdb_id)
                if ext_id and ext_id.startswith("tt"):
                    imdb_id = ext_id
            except Exception:
                pass

        for s in seasons:
            sn = s.get("season_number", 1)
            ep_count = s.get("episode_count", 0)
            s_name = s.get("name", f"Temporada {sn}")
            label = f"{s_name} ({ep_count} episodios)"
            poster_path = s.get("poster_path")
            poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else (show_info.get("poster", "") if show_info else "")

            ui.add_directory_item(
                handle=self.handle, label=label, action="tmdb_episodes",
                base_url=self.base_url, icon="DefaultTVShows.png",
                poster=poster, fanart=show_info.get("background", "") if show_info else "",
                imdb_id=imdb_id, tmdb_id=tmdb_id, media_type="series",
                season=str(sn), title=title, original_title=original_title
            )
        ui.end_directory(self.handle, content_type="seasons")

    def _tmdb_episodes(self):
        tmdb_id = self.params.get("tmdb_id", "")
        season = int(self.params.get("season", "1"))
        title = self.params.get("title", "")
        original_title = self.params.get("original_title", title)
        imdb_id = self.params.get("imdb_id", "")

        episodes = []
        show_info = None
        if tmdb_id:
            try:
                episodes, show_info = self.tmdb.get_tv_episodes(tmdb_id, season)
            except Exception as e:
                log(f"TMDB episodes error: {e}", level="error")

        if not episodes and imdb_id:
            log("TMDB episodes failed. Falling back to Stremio episodes", level="info")
            self._episodes()
            return

        if not episodes:
            ui.show_notification("No se encontraron episodios.")
            ui.end_directory(self.handle)
            return

        # Ensure we have the canonical tt... IMDb ID for Stremio addons
        if (not imdb_id or imdb_id.startswith("tmdb:")) and show_info:
            imdb_id = show_info.get("imdb_id", "")
        if (not imdb_id or imdb_id.startswith("tmdb:")) and tmdb_id:
            try:
                ext_id = self.tmdb.get_external_ids("tv", tmdb_id)
                if ext_id and ext_id.startswith("tt"):
                    imdb_id = ext_id
            except Exception:
                pass

        for ep in episodes:
            ep_num = ep.get("episode", 1)
            ep_title = ep.get("title", f"Episodio {ep_num}")
            
            label = f"{ep_num}. {ep_title}"
            vote = ep.get("vote_average", 0)
            if vote:
                label += f" [COLOR yellow]★{vote:.1f}[/COLOR]"

            ep_imdb_id = f"{imdb_id}:{season}:{ep_num}" if (imdb_id and imdb_id.startswith("tt")) else (f"tmdb:{tmdb_id}:{season}:{ep_num}" if tmdb_id else "")

            sub_url = ui.build_url(
                self.base_url, action="search_subtitles",
                imdb_id=ep_imdb_id or imdb_id, tmdb_id=tmdb_id,
                media_type="series", season=str(season), episode=str(ep_num),
                title=f"{title} S{season:02d}E{ep_num:02d}",
            )
            ep_ctx = [("💬 Buscar Subtítulos (OpenSubtitles)", f"RunPlugin({sub_url})")]

            ui.add_directory_item(
                handle=self.handle, label=label, action="streams",
                base_url=self.base_url, icon="DefaultTVShows.png",
                poster=ep.get("thumbnail", show_info.get("poster", "") if show_info else ""),
                fanart=show_info.get("background", "") if show_info else "",
                plot=ep.get("overview", ""),
                imdb_id=ep_imdb_id, tmdb_id=tmdb_id, media_type="series",
                title=f"{title} S{season:02d}E{ep_num:02d}",
                original_title=f"{original_title} S{season:02d}E{ep_num:02d}",
                series_imdb=imdb_id, season=str(season), episode=str(ep_num),
                context_menu=ep_ctx
            )

        ui.end_directory(self.handle, content_type="episodes")

    def _list_catalogs(self, media_type):
        catalogs = self.stremio.get_catalogs_for_type(media_type)
        if not catalogs:
            ui.show_notification("No catalogs found. Check addon URLs.")
            ui.end_directory(self.handle)
            return
        for cat in catalogs:
            label = f"{cat['name']} ({cat['addon_name']})"
            ui.add_directory_item(
                handle=self.handle, label=label, action="catalog",
                base_url=self.base_url,
                icon="DefaultMovies.png" if media_type == "movie" else "DefaultTVShows.png",
                media_type=media_type,
                addon_url=cat["addon_url"], catalog_id=cat["catalog_id"],
            )
        ui.end_directory(self.handle)

    def _catalog_list_route(self):
        media_type = self.params.get("media_type", "movie")
        self._list_catalogs(media_type)

    # ══════════════════════════════════════════════════════
    #  CATALOG
    # ══════════════════════════════════════════════════════
    def _catalog(self):
        addon_url = self.params.get("addon_url", "")
        catalog_id = self.params.get("catalog_id", "")
        media_type = self.params.get("media_type", "movie")
        skip = int(self.params.get("skip", "0"))

        extra = f"skip={skip}" if skip > 0 else ""
        items = self.stremio.get_catalog(addon_url, media_type, catalog_id, extra)

        if not items:
            ui.show_notification("No items found.")
            ui.end_directory(self.handle)
            return

        items = self.stremio.dedup_items(items)
        self._render_item_list(items, media_type)

        per_page = Config.items_per_page()
        if len(items) >= per_page:
            ui.add_directory_item(
                handle=self.handle, label="[B]>> Siguiente pagina[/B]",
                action="catalog", base_url=self.base_url,
                media_type=media_type, addon_url=addon_url,
                catalog_id=catalog_id, skip=str(skip + per_page),
            )

        content = "movies" if media_type == "movie" else "tvshows"
        ui.end_directory(self.handle, content_type=content)

    # ══════════════════════════════════════════════════════
    #  GENRES
    # ══════════════════════════════════════════════════════
    def _genres(self):
        ui.add_directory_item(
            handle=self.handle, label="Generos de Peliculas", action="genre_list",
            base_url=self.base_url, media_type="movie", icon="DefaultMovies.png",
        )
        ui.add_directory_item(
            handle=self.handle, label="Generos de Series", action="genre_list",
            base_url=self.base_url, media_type="series", icon="DefaultTVShows.png",
        )
        ui.end_directory(self.handle)

    def _genre_list(self):
        media_type = self.params.get("media_type", "movie")
        genre = self.params.get("genre", "")

        if genre:
            items = self.stremio.get_catalog_by_genre(media_type, genre)
            if not items:
                ui.show_notification(f"No results for genre: {genre}")
                ui.end_directory(self.handle)
                return
            items = self.stremio.dedup_items(items)
            self._render_item_list(items, media_type)
            content = "movies" if media_type == "movie" else "tvshows"
            ui.end_directory(self.handle, content_type=content)
        else:
            genres = self.stremio.get_genres(media_type)
            for g in genres:
                ui.add_directory_item(
                    handle=self.handle, label=g, action="genre_list",
                    base_url=self.base_url, media_type=media_type,
                    genre=g, icon="DefaultGenre.png",
                )
            ui.end_directory(self.handle)

    # ══════════════════════════════════════════════════════
    #  SEASONS / EPISODES
    # ══════════════════════════════════════════════════════
    def _seasons(self):
        imdb_id = self.params.get("imdb_id", "")
        title = self.params.get("title", "")

        # Try TMDB seasons first if enabled to avoid raw stremio video duplicates
        if Config.tmdb_enabled():
            try:
                tmdb_id = self.params.get("tmdb_id", "")
                if not tmdb_id and imdb_id:
                    if imdb_id.startswith("tmdb:"):
                        tmdb_id = imdb_id.split("tmdb:")[1]
                    elif imdb_id.startswith("tt"):
                        found_id, _ = self.tmdb.find_by_imdb_id(imdb_id)
                        if found_id:
                            tmdb_id = found_id
                if tmdb_id:
                    self.params["tmdb_id"] = tmdb_id
                    self._tmdb_seasons()
                    return
            except Exception as e:
                log(f"Seasons fallback to TMDB error: {e}", level="debug")

        meta = self.stremio.get_meta("series", imdb_id)
        if not meta:
            ui.show_notification("No se pudo cargar la serie.")
            ui.end_directory(self.handle)
            return

        videos = meta.get("videos", [])
        # Deduplicate videos by season and episode to avoid duplicate counters
        dedup_videos = {}
        for v in videos:
            s_num = v.get("season", 0)
            ep_num = v.get("episode", 0)
            if s_num and (s_num, ep_num) not in dedup_videos:
                dedup_videos[(s_num, ep_num)] = v

        valid_videos = list(dedup_videos.values()) if dedup_videos else videos
        seasons = sorted(set(v.get("season", 0) for v in valid_videos if v.get("season")))

        if not seasons:
            self.params["season"] = "1"
            self._episodes()
            return

        for sn in seasons:
            ec = sum(1 for v in valid_videos if v.get("season") == sn)
            label = f"Temporada {sn} ({ec} episodios)"
            ui.add_directory_item(
                handle=self.handle, label=label, action="episodes",
                base_url=self.base_url, icon="DefaultTVShows.png",
                poster=meta.get("poster", ""), fanart=meta.get("background", ""),
                imdb_id=imdb_id, media_type="series",
                season=str(sn), title=title,
            )
        ui.end_directory(self.handle, content_type="seasons")

    def _episodes(self):
        imdb_id = self.params.get("imdb_id", "")
        season = int(self.params.get("season", "1"))
        title = self.params.get("title", "")

        meta = self.stremio.get_meta("series", imdb_id)
        if not meta:
            ui.show_notification("No se pudo cargar episodios.")
            ui.end_directory(self.handle)
            return

        episodes = sorted(
            [v for v in meta.get("videos", []) if v.get("season") == season],
            key=lambda v: v.get("episode", 0),
        )

        if not episodes:
            ui.show_notification("No hay episodios.")
            ui.end_directory(self.handle)
            return

        for ep in episodes:
            ep_num = ep.get("episode", 0)
            ep_title = ep.get("title", ep.get("name", f"Episodio {ep_num}"))
            ep_id = ep.get("id", f"{imdb_id}:{season}:{ep_num}")

            resume_info = ""
            if Config.resume_enabled():
                r = self.cache.get_resume(ep_id)
                if r:
                    resume_info = f" [COLOR yellow][{int(r['percent'])}%][/COLOR]"

            label = f"{ep_num}. {ep_title}{resume_info}"

            sub_url = ui.build_url(
                self.base_url, action="search_subtitles",
                imdb_id=ep_id or imdb_id, media_type="series",
                season=str(season), episode=str(ep_num),
                title=f"{title} S{season:02d}E{ep_num:02d}",
            )
            ep_ctx = [("💬 Buscar Subtítulos (OpenSubtitles)", f"RunPlugin({sub_url})")]

            ui.add_directory_item(
                handle=self.handle, label=label, action="streams",
                base_url=self.base_url, icon="DefaultTVShows.png",
                poster=ep.get("thumbnail", meta.get("poster", "")),
                fanart=meta.get("background", ""),
                plot=ep.get("overview", ""),
                imdb_id=ep_id, media_type="series",
                title=f"{title} S{season:02d}E{ep_num:02d}",
                series_imdb=imdb_id, season=str(season), episode=str(ep_num),
                context_menu=ep_ctx
            )

        ui.end_directory(self.handle, content_type="episodes")

    # ══════════════════════════════════════════════════════
    #  STREAMS
    # ══════════════════════════════════════════════════════
    def _streams(self):
        imdb_id = self.params.get("imdb_id", "")
        tmdb_id = self.params.get("tmdb_id", "")
        media_type = self.params.get("media_type", "movie")
        title = self.params.get("title", "")
        original_title = self.params.get("original_title", "") or title

        season = self.params.get("season")
        episode = self.params.get("episode")

        # Normalize tmdb_id from imdb_id if needed
        if not tmdb_id and imdb_id and imdb_id.startswith("tmdb:"):
            parts = imdb_id.split(":")
            if len(parts) >= 2:
                tmdb_id = parts[1]
            if len(parts) >= 4 and not season and not episode:
                season = parts[2]
                episode = parts[3]

        # Resolve canonical IMDb ID (tt...) from TMDB if missing or starting with tmdb:
        if not imdb_id or imdb_id.startswith("tmdb:"):
            if tmdb_id:
                try:
                    tmdb_media = "movie" if media_type == "movie" else "tv"
                    resolved_tt = self.tmdb.get_external_ids(tmdb_media, tmdb_id)
                    if resolved_tt and resolved_tt.startswith("tt"):
                        if media_type == "series" and season and episode:
                            imdb_id = f"{resolved_tt}:{season}:{episode}"
                        else:
                            imdb_id = resolved_tt
                except Exception as e:
                    log(f"Error resolving external ID in _streams: {e}", level="error")
        elif media_type == "series" and season and episode and ":" not in imdb_id:
            imdb_id = f"{imdb_id}:{season}:{episode}"

        # Resolve Original Title from TMDB if missing
        if tmdb_id:
            try:
                if not original_title or original_title == title:
                    item_details, _ = self.tmdb.get_details("movie" if media_type == "movie" else "tv", tmdb_id)
                    if item_details:
                        orig = item_details.get("original_title") or item_details.get("title")
                        if orig:
                            if media_type == "series" and season and episode:
                                original_title = f"{orig} S{int(season):02d}E{int(episode):02d}"
                            else:
                                original_title = orig
            except Exception as e:
                log(f"Error resolving TMDB details in _streams: {e}", level="error")

        try:
            category = "movies" if media_type == "movie" else "series"
            streams = []

            # 1. Query Stremio Addons first if imdb_id is available (exact match by ID)
            if imdb_id:
                log(f"Querying Stremio addons for ID: {imdb_id}", level="info")
                stremio_streams = self.stremio.get_streams(media_type, imdb_id)
                if stremio_streams:
                    streams.extend(stremio_streams)

            # 2. Search DHT with Original Title (English/Native)
            if original_title:
                log(f"DHT resolving stream for original title: {original_title}", level="info")
                dht_orig = self.bitsearch.search(original_title, category)
                if dht_orig:
                    existing_hashes = {s.get("infoHash", "").lower() for s in streams if s.get("infoHash")}
                    for s in dht_orig:
                        h = s.get("infoHash", "").lower()
                        if not h or h not in existing_hashes:
                            streams.append(s)

            # 3. Search DHT with Local Title (Spanish) if different
            if title and title != original_title:
                log(f"DHT resolving stream for Spanish title: {title}", level="info")
                es_streams = self.bitsearch.search(title, category)
                if es_streams:
                    existing_hashes = {s.get("infoHash", "").lower() for s in streams if s.get("infoHash")}
                    for s in es_streams:
                        h = s.get("infoHash", "").lower()
                        if not h or h not in existing_hashes:
                            streams.append(s)

            # Filter out false positives / mismatched torrent titles
            streams = self.resolver.filter_by_title_match(
                streams, title=title, original_title=original_title,
                media_type=media_type, season=season, episode=episode
            )

            if not streams:
                ui.show_notification("No se encontraron streams.")
                ui.end_directory(self.handle, succeeded=False)
                return

            if self.rd.is_configured():
                streams = self.rd.tag_cached_streams(streams)

            streams = self.resolver.filter_by_quality(streams)
            streams = self.resolver.filter_spanish(streams)
            streams = self.resolver.sort_streams(streams)

            if Config.torrent_autoplay() and streams:
                ui.end_directory(self.handle, succeeded=True)
                self._launch_stream(streams[0], imdb_id, media_type, title)
                return

            labels = []
            for stream in streams:
                quality = self.resolver.get_quality_label(stream)
                seeds = self.resolver.get_seeds_label(stream)
                size = self.resolver.get_size_label(stream)
                addon_name = stream.get("_addon", "")
                rd_label = self.resolver.get_rd_label(stream)
                esp_label = self.resolver.get_spanish_tag(stream)

                stream_title = stream.get("title", "") or stream.get("name", "Unknown")
                line1 = stream_title.split("\n")[0][:80]

                parts = []
                if esp_label:
                    parts.append(esp_label)
                if rd_label:
                    parts.append(rd_label)
                if quality:
                    parts.append(quality)
                parts.append(line1)
                if seeds:
                    parts.append(seeds)
                if size:
                    parts.append(size)
                if addon_name:
                    parts.append(f"[{addon_name}]")

                labels.append("  ".join(parts))

            ui.end_directory(self.handle, succeeded=True)

            choice = xbmcgui.Dialog().select(
                f"Streams para: {title}" if title else "Seleccionar stream",
                labels,
            )

            if choice < 0:
                return

            self._launch_stream(streams[choice], imdb_id, media_type, title)

        except Exception as e:
            log(f"Stream error: {e}", level="error")
            ui.show_notification(str(e), icon=xbmcgui.NOTIFICATION_ERROR)

    # ══════════════════════════════════════════════════════
    #  SUBTITLES (OpenSubtitles Search & Download)
    # ══════════════════════════════════════════════════════
    def _search_subtitles(self):
        imdb_id = self.params.get("imdb_id", "")
        tmdb_id = self.params.get("tmdb_id", "")
        media_type = self.params.get("media_type", "movie")
        season = self.params.get("season")
        episode = self.params.get("episode")
        title = self.params.get("title", "")

        # Resolve canonical tt... IMDb ID if missing or in tmdb: format
        if not imdb_id or imdb_id.startswith("tmdb:"):
            if not tmdb_id and imdb_id.startswith("tmdb:"):
                parts = imdb_id.split(":")
                if len(parts) >= 2:
                    tmdb_id = parts[1]
                if len(parts) >= 4 and not season and not episode:
                    season = parts[2]
                    episode = parts[3]
            if tmdb_id:
                try:
                    resolved_tt = self.tmdb.get_external_ids("movie" if media_type == "movie" else "tv", tmdb_id)
                    if resolved_tt and resolved_tt.startswith("tt"):
                        imdb_id = resolved_tt
                except Exception as e:
                    log(f"Subtitles TMDB resolve error: {e}", level="debug")

        if not imdb_id:
            ui.show_notification("No se pudo identificar el contenido.")
            return

        ui.show_notification("Buscando en OpenSubtitles...")

        from resources.lib.subtitles import fetch_subtitles_rich, download_subtitle_file, apply_subtitle_to_player

        subs = fetch_subtitles_rich(imdb_id, media_type, season, episode, timeout=8)
        if not subs:
            ui.show_notification("No se encontraron subtítulos en OpenSubtitles.")
            return

        es_subs = [s for s in subs if s.get("lang") in ("spa", "es", "spl", "lat")]
        en_subs = [s for s in subs if s.get("lang") in ("eng", "en")]
        other_subs = [s for s in subs if s not in es_subs and s not in en_subs]

        options = []
        if es_subs:
            options.append(f"🇪🇸 Español ({len(es_subs)} disponibles)")
        if en_subs:
            options.append(f"🇬🇧 Inglés ({len(en_subs)} disponibles)")
        if other_subs:
            options.append(f"🌐 Otros idiomas ({len(other_subs)} disponibles)")
        options.append(f"📋 Ver todos ({len(subs)} subtítulos)")

        selected_subs = subs
        if len(options) > 1:
            idx = xbmcgui.Dialog().select("Filtrar por idioma (OpenSubtitles)", options)
            if idx == -1:
                return
            opt_text = options[idx]
            if "Español" in opt_text:
                selected_subs = es_subs
            elif "Inglés" in opt_text:
                selected_subs = en_subs
            elif "Otros" in opt_text:
                selected_subs = other_subs
            else:
                selected_subs = subs

        items = []
        for s in selected_subs:
            flag = s.get("flag", "🌐")
            fn = s.get("filename", "")
            fmt = s.get("format", "SRT")
            fps = f"{s['fps']}fps" if s.get("fps") else ""
            tag = s.get("tag", "")

            meta_parts = [p for p in [tag, fmt, fps] if p]
            meta_str = f"[{' | '.join(meta_parts)}]" if meta_parts else ""
            label = f"{flag} {meta_str} {fn}"
            items.append(label)

        sub_idx = xbmcgui.Dialog().select(f"Subtítulos para: {title or imdb_id}", items)
        if sub_idx == -1:
            return

        chosen_sub = selected_subs[sub_idx]
        sub_url = chosen_sub.get("url")
        sub_filename = chosen_sub.get("filename", "subtitle.srt")

        ui.show_notification(f"Descargando {chosen_sub.get('lang_name', 'subtítulo')}...")

        local_path = download_subtitle_file(sub_url, sub_filename)
        if not local_path or not os.path.exists(local_path):
            ui.show_notification("Error al descargar el subtítulo.", icon=xbmcgui.NOTIFICATION_ERROR)
            return

        self.cache.set(f"selected_sub_{imdb_id}", local_path, ttl=86400)

        applied = apply_subtitle_to_player(local_path)
        if applied:
            ui.show_notification(f"✓ Subtítulo activado: {chosen_sub.get('lang_name')}")
        else:
            ui.show_notification("✓ Subtítulo descargado para reproducción.")

    # ══════════════════════════════════════════════════════
    #  PLAY
    # ══════════════════════════════════════════════════════
    def _play(self):
        imdb_id = self.params.get("imdb_id", "")
        media_type = self.params.get("media_type", "movie")
        title = self.params.get("title", "")

        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(300)

        # 1. First query DHT Search using the query title
        log(f"DHT resolving stream first for direct play: {title}", level="info")
        category = "movies" if media_type == "movie" else "series"
        streams = self.bitsearch.search(title, category)

        # 2. Fallback to Stremio Addons if no DHT streams found
        if not streams:
            log(f"DHT returned no results for direct play: {title}. Falling back to Stremio addons", level="info")
            streams = self.stremio.get_streams(media_type, imdb_id)

        if not streams:
            ui.show_notification("No streams found.")
            return

        if self.rd.is_configured():
            streams = self.rd.tag_cached_streams(streams)

        streams = self.resolver.filter_by_quality(streams)
        streams = self.resolver.filter_spanish(streams)
        streams = self.resolver.sort_streams(streams)

        self._launch_stream(streams[0], imdb_id, media_type, title)

    def _launch_stream(self, stream, imdb_id, media_type, title):
        playable_url = self.resolver.resolve(stream)
        if not playable_url:
            ui.show_notification("No se pudo resolver el stream.")
            return

        try:
            base_imdb = imdb_id.split(":")[0] if ":" in imdb_id else imdb_id
            self.cache.add_history(base_imdb, media_type, title,
                                   stream.get("_poster", ""))
        except Exception:
            pass

        season = self.params.get("season", "")
        episode = self.params.get("episode", "")
        series_imdb = self.params.get("series_imdb", "") or imdb_id

        show_title = ""
        if media_type == "series":
            show_title = self.params.get("series_title") or re.sub(r"\s+S\d+E\d+.*$", "", title, flags=re.I).strip()

        context = {
            "content_id": imdb_id,
            "media_type": media_type,
            "title": title,
            "series_title": show_title,
            "poster": stream.get("_poster", "") or self.params.get("poster", ""),
            "imdb_id": series_imdb,
            "season": season,
            "episode": episode,
        }
        self.cache.set("_playback_context", context, ttl=7200)

        if Config.trakt_enabled() and media_type == "movie":
            try:
                self.trakt.mark_watched(imdb_id.split(":")[0], media_type)
            except Exception:
                pass

        sub_list = []
        local_custom_sub = self.cache.get(f"selected_sub_{imdb_id}")
        if local_custom_sub and os.path.exists(local_custom_sub):
            sub_list.append(local_custom_sub)

        if imdb_id:
            try:
                from resources.lib.subtitles import prepare_subtitles_for_playback
                prepared = prepare_subtitles_for_playback(imdb_id.split(":")[0], media_type, season, episode)
                for su in prepared:
                    if su not in sub_list:
                        sub_list.append(su)
            except Exception as e:
                log(f"Subtitle prepare error: {e}", level="debug")

        # Build complete ListItem with Video metadata so Kodi subtitle downloader has the exact title & season & episode
        li = xbmcgui.ListItem(label=title, path=playable_url)
        info = {
            "title": title,
            "mediatype": "movie" if media_type == "movie" else "episode",
        }
        if media_type == "series":
            if show_title:
                info["tvshowtitle"] = show_title
            if season:
                try:
                    info["season"] = int(season)
                except (ValueError, TypeError):
                    pass
            if episode:
                try:
                    info["episode"] = int(episode)
                except (ValueError, TypeError):
                    pass
        elif self.params.get("original_title"):
            info["originaltitle"] = self.params.get("original_title")

        if imdb_id:
            info["imdbnumber"] = imdb_id.split(":")[0]

        li.setInfo("video", info)

        art = {}
        poster_url = stream.get("_poster") or self.params.get("poster", "")
        if poster_url:
            art["poster"] = poster_url
            art["thumb"] = poster_url
            art["icon"] = poster_url
        if art:
            li.setArt(art)

        if sub_list:
            try:
                li.setSubtitles(sub_list)
            except Exception:
                pass

        if playable_url.startswith("plugin://"):
            log(f"PlayMedia -> {playable_url[:100]}", level="info")
            try:
                xbmc.Player().play(playable_url, li)
            except Exception as e:
                log(f"Player.play exception: {e}, using PlayMedia", level="warning")
                xbmc.executebuiltin(f'PlayMedia("{playable_url}")')

            if local_custom_sub and os.path.exists(local_custom_sub):
                def _apply_delayed_sub(path):
                    import time
                    for _ in range(30):
                        time.sleep(1)
                        if xbmc.Player().isPlaying():
                            try:
                                xbmc.Player().setSubtitles(path)
                                xbmc.Player().showSubtitles(True)
                                log(f"Injected custom subtitle to Player: {path}", level="info")
                                break
                            except Exception:
                                pass
                threading.Thread(target=_apply_delayed_sub, args=[local_custom_sub]).start()
        else:
            log(f"Player.play -> {playable_url[:100]}", level="info")
            if sub_list:
                ui.show_notification("Subtítulos cargados")
            xbmc.Player().play(playable_url, li)

    # ══════════════════════════════════════════════════════
    #  MANUAL TORRENT / MAGNET
    # ══════════════════════════════════════════════════════
    def _manual_torrent(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(200)

        text = ui.show_input("Pegar Magnet o URL de torrent")
        if not text:
            return

        text = text.strip()
        if not (text.startswith("magnet:") or text.startswith("http")):
            ui.show_notification("Formato no valido. Usa magnet: o http://")
            return

        ui.show_notification("Resolviendo...", time=2000)
        playable_url, url_type = self.resolver.resolve_magnet(text)

        if not playable_url:
            ui.show_notification("No se pudo resolver.")
            return

        log(f"Manual play ({url_type}): {playable_url}", level="info")

        if playable_url.startswith("plugin://"):
            xbmc.executebuiltin(f'PlayMedia("{playable_url}")')
        else:
            li = xbmcgui.ListItem(label="Manual Torrent", path=playable_url)
            xbmc.Player().play(playable_url, li)

    # ══════════════════════════════════════════════════════
    #  DHT SEARCH
    # ══════════════════════════════════════════════════════
    def _dht_search(self):
        query = self.params.get("query", "")
        if not query:
            query = ui.show_input("Buscar película, serie o torrent...")
            if not query:
                ui.end_directory(self.handle, succeeded=False)
                return

        # 1. Unified Search via TMDB Multi-Search
        items = []
        try:
            items, _ = self.tmdb.search_multi(query)
        except Exception as e:
            log(f"TMDB search_multi error: {e}", level="error")

        if items:
            ui.add_directory_item(
                handle=self.handle,
                label=f"[COLOR cyan][B]🔍 Buscar torrents directos en DHT para: '{query}'[/B][/COLOR]",
                action="raw_dht_search",
                base_url=self.base_url,
                icon="DefaultAddonsSearch.png",
                query=query
            )
            items = self.stremio.dedup_items(items) if hasattr(self.stremio, "dedup_items") else items
            self._render_item_list(items, "movie")
            ui.end_directory(self.handle)
            return

        # 2. Direct fallback to raw DHT search if no TMDB items returned
        self._raw_dht_search_with_query(query)

    def _raw_dht_search(self):
        query = self.params.get("query", "")
        if not query:
            query = ui.show_input("Buscar Torrent en DHT (ej: Iron Man 1080p)")
            if not query:
                ui.end_directory(self.handle, succeeded=False)
                return
        self._raw_dht_search_with_query(query)

    def _raw_dht_search_with_query(self, query):
        categories = [
            "• 🎬 Películas (Video)",
            "• 📺 Series (TV)",
            "• 🎵 Música"
        ]
        cat_choice = xbmcgui.Dialog().select("Seleccionar Categoría", categories)
        if cat_choice < 0:
            return

        category_map = {
            0: "movies",
            1: "series",
            2: "music"
        }
        category = category_map[cat_choice]

        dialog = xbmcgui.DialogProgress()
        dialog.create("DHT Search", f'Buscando "{query}" en Kademlia DHT...')
        dialog.update(10)

        try:
            streams = self.bitsearch.search(query, category)
            dialog.update(40, "Comprobando caché Real-Debrid...")

            if self.rd.is_configured():
                streams = self.rd.tag_cached_streams(streams)

            dialog.update(60, "Filtrando y Ordenando...")

            if not streams:
                dialog.close()
                ui.show_notification("No se encontraron torrents en DHT.")
                return

            streams = self.resolver.filter_by_quality(streams)
            streams = self.resolver.filter_spanish(streams)
            streams = self.resolver.sort_streams(streams)

            dialog.update(90, f"{len(streams)} torrents listos")
            dialog.close()

            labels = []
            for stream in streams:
                quality = self.resolver.get_quality_label(stream)
                seeds = self.resolver.get_seeds_label(stream)
                size = self.resolver.get_size_label(stream)
                addon_name = stream.get("_addon", "")
                rd_label = self.resolver.get_rd_label(stream)
                esp_label = self.resolver.get_spanish_tag(stream)

                stream_title = stream.get("title", "") or stream.get("name", "Unknown")
                line1 = stream_title.split("\n")[0][:80]

                parts = []
                if esp_label:
                    parts.append(esp_label)
                if rd_label:
                    parts.append(rd_label)
                if quality:
                    parts.append(quality)
                parts.append(line1)
                if seeds:
                    parts.append(seeds)
                if size:
                    parts.append(size)
                if addon_name:
                    parts.append(f"[{addon_name}]")

                labels.append("  ".join(parts))

            choice = xbmcgui.Dialog().select(
                f"Resultados DHT: {query}",
                labels,
            )

            if choice < 0:
                return

            self._launch_dht_stream(streams[choice], query)

        except Exception as e:
            try:
                dialog.close()
            except Exception:
                pass
            log(f"DHT Search error: {e}", level="error")
            ui.show_notification(str(e), icon=xbmcgui.NOTIFICATION_ERROR)

    def _launch_dht_stream(self, stream, title):
        playable_url = self.resolver.resolve(stream)
        if not playable_url:
            ui.show_notification("No se pudo resolver el torrent.")
            return

        # Clean title to use the actual stream name if available
        stream_title = stream.get("title", "") or stream.get("name", "") or title
        stream_title = stream_title.split("\n")[0]

        if playable_url.startswith("plugin://"):
            log(f"DHT PlayMedia -> {playable_url[:100]}", level="info")
            xbmc.executebuiltin(f'PlayMedia("{playable_url}")')
        else:
            log(f"DHT Player.play -> {playable_url[:100]}", level="info")
            li = xbmcgui.ListItem(label=stream_title, path=playable_url)
            xbmc.Player().play(playable_url, li)

    # ══════════════════════════════════════════════════════
    #  TRENDING TORRENTS
    # ══════════════════════════════════════════════════════
    def _trending(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(200)

        choice = xbmcgui.Dialog().select(
            "Seleccionar Categoría Trending",
            ["Top Torrents (Últimas 48h)", "Torrents Más Recientes (Nuevos)"]
        )
        if choice < 0:
            return

        trend_type = "48h" if choice == 0 else "recent"
        title_label = "Top 48h" if choice == 0 else "Recientes"

        dialog = xbmcgui.DialogProgress()
        dialog.create("Trending Torrents", f"Obteniendo {title_label}...")
        dialog.update(20)

        try:
            streams = self.bitsearch.trending(trend_type)
            dialog.update(40, "Comprobando caché Real-Debrid...")

            if self.rd.is_configured():
                streams = self.rd.tag_cached_streams(streams)

            dialog.update(60, "Filtrando y Ordenando...")

            if not streams:
                dialog.close()
                ui.show_notification("No se encontraron torrents en tendencias.")
                return

            streams = self.resolver.filter_by_quality(streams)
            streams = self.resolver.filter_spanish(streams)
            streams = self.resolver.sort_streams(streams)

            dialog.update(90, f"{len(streams)} torrents listos")
            dialog.close()

            labels = []
            for stream in streams:
                quality = self.resolver.get_quality_label(stream)
                seeds = self.resolver.get_seeds_label(stream)
                size = self.resolver.get_size_label(stream)
                addon_name = stream.get("_addon", "")
                rd_label = self.resolver.get_rd_label(stream)
                esp_label = self.resolver.get_spanish_tag(stream)

                stream_title = stream.get("title", "") or stream.get("name", "Unknown")
                line1 = stream_title.split("\n")[0][:80]

                parts = []
                if esp_label:
                    parts.append(esp_label)
                if rd_label:
                    parts.append(rd_label)
                if quality:
                    parts.append(quality)
                parts.append(line1)
                if seeds:
                    parts.append(seeds)
                if size:
                    parts.append(size)
                if addon_name:
                    parts.append(f"[{addon_name}]")

                labels.append("  ".join(parts))

            selected = xbmcgui.Dialog().select(
                f"Trending Torrents ({title_label})",
                labels,
            )

            if selected < 0:
                return

            self._launch_dht_stream(streams[selected], title_label)

        except Exception as e:
            try:
                dialog.close()
            except Exception:
                pass
            log(f"Trending Torrents error: {e}", level="error")
            ui.show_notification(str(e), icon=xbmcgui.NOTIFICATION_ERROR)

    # ══════════════════════════════════════════════════════
    #  SEARCH
    # ══════════════════════════════════════════════════════
    def _search(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(200)

        query = ui.show_input("Buscar peliculas y series")
        if not query:
            return

        choice = ui.show_select("Buscar en:", ["Peliculas", "Series", "Ambos"])
        if choice < 0:
            return

        type_map = {0: "movie", 1: "series", 2: "both"}
        url = ui.build_url(
            self.base_url, action="search_results",
            query=query, search_type=type_map[choice],
        )
        xbmc.executebuiltin(f"Container.Update({url})")

    def _search_results(self):
        query = self.params.get("query", "")
        search_type = self.params.get("search_type", "movie")
        if not query:
            ui.end_directory(self.handle)
            return

        dialog = xbmcgui.DialogProgress()
        dialog.create("Buscando", f'"{query}"...')
        dialog.update(10)

        all_results = []
        if search_type in ("movie", "both"):
            dialog.update(30, "Peliculas...")
            all_results.extend(
                [(r, "movie") for r in self.stremio.search(query, "movie")]
            )
        if search_type in ("series", "both"):
            dialog.update(60, "Series...")
            all_results.extend(
                [(r, "series") for r in self.stremio.search(query, "series")]
            )

        dialog.close()

        if not all_results:
            ui.show_notification(f'Sin resultados para "{query}"')
            ui.end_directory(self.handle)
            return

        seen = set()
        for item, mt in all_results:
            imdb_id = item.get("imdb_id") or item.get("id", "")
            if imdb_id in seen:
                continue
            seen.add(imdb_id)

            name = item.get("name", "Unknown")
            year = str(item.get("releaseInfo", item.get("year", "")))
            poster = item.get("poster", "")
            plot = item.get("description", "")

            tag = "[PELICULA]" if mt == "movie" else "[SERIE]"
            label = f"{tag} {name} ({year})" if year else f"{tag} {name}"
            click = "streams" if mt == "movie" else "seasons"

            ctx = self._make_fav_context(imdb_id, mt, name, year, poster)

            ui.add_directory_item(
                handle=self.handle, label=label, action=click,
                base_url=self.base_url, poster=poster, plot=plot,
                year=year, imdb_id=imdb_id, media_type=mt,
                context_menu=ctx, title=name,
            )

        ui.end_directory(self.handle, content_type="videos")

    # ══════════════════════════════════════════════════════
    #  CONTINUE WATCHING
    # ══════════════════════════════════════════════════════
    def _continue_watching(self):
        items = self.cache.get_continue_watching(limit=20)
        if not items:
            ui.show_notification("Nada en 'Seguir viendo'.")
            ui.end_directory(self.handle)
            return

        for item in items:
            pct = int(item["percent"])
            title = item["title"]
            label = f"{title} [COLOR yellow][{pct}%][/COLOR]"

            ui.add_directory_item(
                handle=self.handle, label=label, action="streams",
                base_url=self.base_url,
                poster=item.get("poster", ""),
                imdb_id=item["content_id"],
                media_type=item["media_type"],
                title=title,
            )

        ui.end_directory(self.handle, content_type="videos")

    # ══════════════════════════════════════════════════════
    #  FAVORITES
    # ══════════════════════════════════════════════════════
    def _favorites(self):
        favs = self.cache.get_favorites()
        if not favs:
            ui.show_notification("No hay favoritos.")
            ui.end_directory(self.handle)
            return

        for fav in favs:
            imdb_id = fav["imdb_id"]
            mt = fav["media_type"]
            title = fav["title"]
            year = fav.get("year", "")
            poster = fav.get("poster", "")
            label = f"{title} ({year})" if year else title

            tmdb_id = ""
            if imdb_id.startswith("tmdb:"):
                tmdb_id = imdb_id.split("tmdb:")[1]
                try:
                    ext_id = self.tmdb.get_external_ids("tv" if mt == "series" else "movie", tmdb_id)
                    if ext_id and ext_id.startswith("tt"):
                        imdb_id = ext_id
                except Exception as e:
                    log(f"TMDB favorite resolve error: {e}", level="debug")
            elif imdb_id.startswith("tt") and Config.tmdb_enabled():
                try:
                    found_id, _ = self.tmdb.find_by_imdb_id(imdb_id)
                    if found_id:
                        tmdb_id = found_id
                except Exception as e:
                    log(f"TMDB favorite resolve error: {e}", level="debug")

            if mt == "series":
                click = "tmdb_seasons" if (tmdb_id or Config.tmdb_enabled()) else "seasons"
            else:
                click = "streams"

            ctx_url = ui.build_url(
                self.base_url, action="toggle_favorite",
                imdb_id=imdb_id, media_type=mt,
                title=title, year=year, poster=poster,
            )
            ctx = [("Quitar de Favoritos", f"RunPlugin({ctx_url})")]

            if mt == "movie":
                sub_url = ui.build_url(
                    self.base_url, action="search_subtitles",
                    imdb_id=imdb_id, tmdb_id=tmdb_id,
                    media_type=mt, title=title,
                )
                ctx.append(("💬 Buscar Subtítulos (OpenSubtitles)", f"RunPlugin({sub_url})"))

            kwargs = {
                "handle": self.handle, "label": label, "action": click,
                "base_url": self.base_url, "poster": poster, "year": year,
                "imdb_id": imdb_id, "media_type": mt, "context_menu": ctx, "title": title,
            }
            if tmdb_id:
                kwargs["tmdb_id"] = tmdb_id

            ui.add_directory_item(**kwargs)

        ui.end_directory(self.handle, content_type="videos")

    def _toggle_favorite(self):
        imdb_id = self.params.get("imdb_id", "")
        mt = self.params.get("media_type", "movie")
        title = self.params.get("title", "")
        year = self.params.get("year", "")
        poster = self.params.get("poster", "")

        if self.cache.is_favorite(imdb_id):
            self.cache.remove_favorite(imdb_id)
            ui.show_notification(f"Eliminado: {title}")
        else:
            self.cache.add_favorite(imdb_id, mt, title, year, poster)
            ui.show_notification(f"Agregado: {title}")
        xbmc.executebuiltin("Container.Refresh")

    # ══════════════════════════════════════════════════════
    #  HISTORY
    # ══════════════════════════════════════════════════════
    def _history(self):
        items = self.cache.get_history(limit=50)
        if not items:
            ui.show_notification("No hay historial.")
            ui.end_directory(self.handle)
            return

        for item in items:
            label = item["title"]
            click = "streams" if item["media_type"] == "movie" else "seasons"
            ui.add_directory_item(
                handle=self.handle, label=label, action=click,
                base_url=self.base_url, poster=item.get("poster", ""),
                imdb_id=item["imdb_id"], media_type=item["media_type"],
                title=item["title"],
            )

        ui.add_directory_item(
            handle=self.handle, label="[COLOR red]Borrar historial[/COLOR]",
            action="clear_history", base_url=self.base_url,
        )
        ui.end_directory(self.handle, content_type="videos")

    # ══════════════════════════════════════════════════════
    #  TRAKT
    # ══════════════════════════════════════════════════════
    def _trakt_menu(self):
        items = [
            ("Mi Watchlist - Peliculas", "trakt_watchlist", "movie"),
            ("Mi Watchlist - Series",    "trakt_watchlist", "series"),
            ("Recomendaciones",          "trakt_recommendations", ""),
            ("Trending - Peliculas",     "trakt_trending",  "movie"),
            ("Trending - Series",        "trakt_trending",  "series"),
            ("Autorizar Trakt...",       "trakt_auth",      ""),
        ]
        for label, action, mt in items:
            ui.add_directory_item(
                handle=self.handle, label=label, action=action,
                base_url=self.base_url, media_type=mt,
            )
        ui.end_directory(self.handle)

    def _trakt_auth(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(200)
        self.trakt.device_auth()

    def _trakt_watchlist(self):
        mt = self.params.get("media_type", "movie")
        api_type = "movies" if mt == "movie" else "shows"
        items = self.trakt.get_watchlist(api_type)
        if not items:
            ui.show_notification("Watchlist vacia.")
            ui.end_directory(self.handle)
            return
        self._render_trakt_items(items)
        ui.end_directory(self.handle, content_type="videos")

    def _trakt_recommendations(self):
        movies = self.trakt.get_recommendations("movies", limit=15)
        shows = self.trakt.get_recommendations("shows", limit=15)
        items = movies + shows
        if not items:
            ui.show_notification("No hay recomendaciones.")
            ui.end_directory(self.handle)
            return
        self._render_trakt_items(items)
        ui.end_directory(self.handle, content_type="videos")

    def _trakt_trending(self):
        mt = self.params.get("media_type", "movie")
        api_type = "movies" if mt == "movie" else "shows"
        items = self.trakt.get_trending(api_type, limit=25)
        if not items:
            ui.show_notification("No trending data.")
            ui.end_directory(self.handle)
            return
        self._render_trakt_items(items)
        ui.end_directory(self.handle, content_type="videos")

    def _trakt_add(self):
        imdb_id = self.params.get("imdb_id", "")
        mt = self.params.get("media_type", "movie")
        self.trakt.add_to_watchlist(imdb_id, mt)
        ui.show_notification("Agregado a Trakt Watchlist")

    def _trakt_remove(self):
        imdb_id = self.params.get("imdb_id", "")
        mt = self.params.get("media_type", "movie")
        self.trakt.remove_from_watchlist(imdb_id, mt)
        ui.show_notification("Eliminado de Trakt Watchlist")
        xbmc.executebuiltin("Container.Refresh")

    def _render_trakt_items(self, items):
        for item in items:
            imdb_id = item.get("imdb_id", "")
            mt = item.get("media_type", "movie")
            title = item.get("title", "Unknown")
            year = item.get("year", "")

            poster = ""
            meta = self.stremio.get_meta(mt, imdb_id) if imdb_id else None
            if meta:
                poster = meta.get("poster", "")
                title = meta.get("name", title)

            tag = "[PELICULA]" if mt == "movie" else "[SERIE]"
            label = f"{tag} {title} ({year})" if year else f"{tag} {title}"
            click = "streams" if mt == "movie" else "seasons"

            ctx = self._make_fav_context(imdb_id, mt, title, year, poster)
            trakt_ctx_url = ui.build_url(
                self.base_url, action="trakt_remove",
                imdb_id=imdb_id, media_type=mt,
            )
            ctx.append(("Quitar de Trakt Watchlist", f"RunPlugin({trakt_ctx_url})"))

            ui.add_directory_item(
                handle=self.handle, label=label, action=click,
                base_url=self.base_url, poster=poster, year=year,
                imdb_id=imdb_id, media_type=mt, context_menu=ctx, title=title,
            )

    # ══════════════════════════════════════════════════════
    #  v3.2 FIX: STREAMING PLATFORMS (no duplicates)
    #  Now shows grouped platforms with sub-menu for type.
    # ══════════════════════════════════════════════════════
    def _platforms(self):
        try:
            platforms = self.stremio.get_streaming_platforms()
            if not platforms:
                ui.show_notification("No se pudieron cargar las plataformas.")
                ui.end_directory(self.handle)
                return

            for plat in platforms:
                name = plat["name"]
                catalogs = plat["catalogs"]

                # If only one catalog, go directly to it
                if len(catalogs) == 1:
                    cat = catalogs[0]
                    ui.add_directory_item(
                        handle=self.handle, label=name, action="platform_catalog",
                        base_url=self.base_url,
                        media_type=cat["type"],
                        catalog_id=cat["catalog_id"],
                        addon_url=cat["addon_url"],
                        icon="DefaultStudios.png",
                    )
                else:
                    # Multiple catalogs (movie + series) → show sub-menu
                    # Encode catalogs list as JSON in a param
                    import json as jsonlib
                    catalogs_json = jsonlib.dumps(catalogs, separators=(',', ':'))
                    ui.add_directory_item(
                        handle=self.handle, label=name, action="platform_type",
                        base_url=self.base_url,
                        platform_name=name,
                        catalogs_data=catalogs_json,
                        icon="DefaultStudios.png",
                    )
            ui.end_directory(self.handle)
        except Exception as e:
            log(f"Platforms error: {e}", level="error")
            ui.show_notification("Error cargando plataformas.")
            ui.end_directory(self.handle)

    def _platform_type(self):
        """Sub-menu: choose Movies or Series for a platform."""
        try:
            import json as jsonlib
            platform_name = self.params.get("platform_name", "")
            catalogs_json = self.params.get("catalogs_data", "[]")
            catalogs = jsonlib.loads(catalogs_json)

            if not catalogs:
                ui.show_notification("No hay catalogos.")
                ui.end_directory(self.handle)
                return

            type_labels = {"movie": "Peliculas", "series": "Series"}
            for cat in catalogs:
                cat_type = cat.get("type", "movie")
                label = f"{platform_name} — {type_labels.get(cat_type, cat_type.title())}"
                ui.add_directory_item(
                    handle=self.handle, label=label, action="platform_catalog",
                    base_url=self.base_url,
                    media_type=cat_type,
                    catalog_id=cat["catalog_id"],
                    addon_url=cat["addon_url"],
                    icon="DefaultStudios.png",
                )
            ui.end_directory(self.handle)
        except Exception as e:
            log(f"Platform type error: {e}", level="error")
            ui.show_notification("Error.")
            ui.end_directory(self.handle)

    def _platform_catalog(self):
        try:
            addon_url = self.params.get("addon_url", "")
            catalog_id = self.params.get("catalog_id", "")
            media_type = self.params.get("media_type", "movie")
            skip = int(self.params.get("skip", "0"))

            extra = f"skip={skip}" if skip > 0 else ""
            items = self.stremio.get_catalog(addon_url, media_type, catalog_id, extra)

            if not items:
                ui.show_notification("No items found.")
                ui.end_directory(self.handle)
                return

            items = self.stremio.dedup_items(items)
            self._render_item_list(items, media_type)

            per_page = Config.items_per_page()
            if len(items) >= 10:
                ui.add_directory_item(
                    handle=self.handle, label="[B]>> Siguiente pagina[/B]",
                    action="platform_catalog", base_url=self.base_url,
                    media_type=media_type, addon_url=addon_url,
                    catalog_id=catalog_id, skip=str(skip + per_page),
                )

            content = "movies" if media_type == "movie" else "tvshows"
            ui.end_directory(self.handle, content_type=content)
        except Exception as e:
            log(f"Platform catalog error: {e}", level="error")
            ui.show_notification("Error cargando catalogo.")
            ui.end_directory(self.handle)

    # ══════════════════════════════════════════════════════
    #  v3.2 NEW: ACESTREAM — Replaces Live TV
    # ══════════════════════════════════════════════════════
    def _acestream(self):
        """AceStream main menu: groups + utilities."""
        try:
            from resources.lib.acestream import AceStreamClient
            ace = AceStreamClient()

            # Show loading notification
            ui.show_notification("Cargando canales AceStream...", time=2000)

            channels = ace.fetch_channels()
            if not channels:
                ui.show_notification("No se pudieron cargar canales AceStream.")
                # Still show utility options
                ui.add_directory_item(
                    handle=self.handle,
                    label="[COLOR yellow]Pegar hash/enlace AceStream[/COLOR]",
                    action="acestream_manual", base_url=self.base_url,
                    icon="DefaultNetwork.png",
                    is_folder=False,
                )
                ui.add_directory_item(
                    handle=self.handle,
                    label="[COLOR cyan]Refrescar lista[/COLOR]",
                    action="acestream_refresh", base_url=self.base_url,
                    icon="DefaultAddonProgram.png",
                    is_folder=False,
                )
                ui.end_directory(self.handle)
                return

            groups = ace.get_groups(channels)

            # Header: show all channels
            total = len(channels)
            ui.add_directory_item(
                handle=self.handle,
                label=f"[B]Todos los canales ({total})[/B]",
                action="acestream_all", base_url=self.base_url,
                icon="DefaultPVRTVChannels.png",
            )

            # Groups
            for group in groups:
                count = group["count"]
                name = group["name"]
                logo = group.get("logo", "")
                label = f"{name} ({count})"
                ui.add_directory_item(
                    handle=self.handle, label=label, action="acestream_group",
                    base_url=self.base_url,
                    poster=logo,
                    group_name=name,
                    icon="DefaultPVRTVChannels.png",
                )

            # Utilities at the bottom
            ui.add_directory_item(
                handle=self.handle,
                label="[COLOR yellow]Pegar hash/enlace AceStream[/COLOR]",
                action="acestream_manual", base_url=self.base_url,
                icon="DefaultNetwork.png",
                is_folder=False,
            )
            ui.add_directory_item(
                handle=self.handle,
                label="[COLOR cyan]Refrescar lista[/COLOR]",
                action="acestream_refresh", base_url=self.base_url,
                icon="DefaultAddonProgram.png",
                is_folder=False,
            )

            # VPN status toggle (CoreELEC / ConnMan)
            if self._is_vpn_supported():
                vpn_on = self._is_vpn_connected()
                if vpn_on:
                    vpn_label = "[COLOR lightgreen]🛡️ VPN Surfshark: CONECTADA (NL)[/COLOR]"
                else:
                    vpn_label = "[COLOR red]🛡️ VPN Surfshark: DESCONECTADA (Pulsar para activar)[/COLOR]"
                ui.add_directory_item(
                    handle=self.handle,
                    label=vpn_label,
                    action="vpn_toggle",
                    base_url=self.base_url,
                    icon="DefaultNetwork.png",
                )

            ui.end_directory(self.handle)
        except Exception as e:
            log(f"AceStream error: {e}", level="error")
            import traceback
            log(traceback.format_exc(), level="error")
            ui.show_notification(f"Error AceStream: {str(e)[:60]}")
            ui.end_directory(self.handle)

    def _acestream_group(self):
        """Show channels in a specific group."""
        try:
            from resources.lib.acestream import AceStreamClient
            ace = AceStreamClient()
            group_name = self.params.get("group_name", "")

            channels = ace.fetch_channels()
            group_channels = ace.get_channels_by_group(group_name, channels)

            if not group_channels:
                ui.show_notification(f"No hay canales en {group_name}.")
                ui.end_directory(self.handle)
                return

            health = ace.check_channels_health(group_channels)

            for ch in group_channels:
                title = ch.get("title", "Canal")
                ace_hash = ch.get("hash", "")
                logo = ch.get("logo", "")

                status = health.get(ace_hash)
                if status == "online":
                    dot = "[COLOR lightgreen]●[/COLOR] "
                elif status == "offline":
                    dot = "[COLOR red]●[/COLOR] "
                else:
                    dot = ""

                ui.add_directory_item(
                    handle=self.handle, label=f"{dot}{title}", action="acestream_play",
                    base_url=self.base_url,
                    poster=logo,
                    ace_hash=ace_hash,
                    title=title,
                    is_folder=False,
                    icon="DefaultPVRTVChannels.png",
                )

            ui.end_directory(self.handle, content_type="videos")
        except Exception as e:
            log(f"AceStream group error: {e}", level="error")
            ui.show_notification("Error cargando grupo.")
            ui.end_directory(self.handle)

    def _acestream_all(self):
        """Show ALL acestream channels in a flat list."""
        try:
            from resources.lib.acestream import AceStreamClient
            ace = AceStreamClient()
            channels = ace.fetch_channels()

            if not channels:
                ui.show_notification("No hay canales.")
                ui.end_directory(self.handle)
                return

            health = ace.check_channels_health(channels)

            for ch in channels:
                title = ch.get("title", "Canal")
                ace_hash = ch.get("hash", "")
                logo = ch.get("logo", "")
                group = ch.get("group", "")

                status = health.get(ace_hash)
                if status == "online":
                    dot = "[COLOR lightgreen]●[/COLOR] "
                elif status == "offline":
                    dot = "[COLOR red]●[/COLOR] "
                else:
                    dot = ""

                label = f"{dot}[{group}] {title}" if group else f"{dot}{title}"

                ui.add_directory_item(
                    handle=self.handle, label=label, action="acestream_play",
                    base_url=self.base_url,
                    poster=logo,
                    ace_hash=ace_hash,
                    title=title,
                    is_folder=False,
                    icon="DefaultPVRTVChannels.png",
                )

            ui.end_directory(self.handle, content_type="videos")
        except Exception as e:
            log(f"AceStream all error: {e}", level="error")
            ui.show_notification("Error.")
            ui.end_directory(self.handle)

    def _play_acestream_hash(self, ace_hash, title="AceStream"):
        """Resolve and play an AceStream stream with monitored prebuffering and direct MPEG-TS playback."""
        try:
            from resources.lib.acestream import AceStreamClient
            engine = Config.acestream_engine()
            log(f"AceStream play requested: hash={ace_hash}, title={title}, engine={engine}", level="info")

            play_url = AceStreamClient.build_play_url(ace_hash, title)

            if play_url.startswith("plugin://"):
                xbmc.executebuiltin(f'PlayMedia("{play_url}")')
                return

            if play_url.startswith("acestream://"):
                try:
                    if xbmc.getCondVisibility("System.Platform.Android"):
                        intent_url = (
                            f"StartAndroidActivity(org.acestream.media,"
                            f"android.intent.action.VIEW,,"
                            f"acestream://{ace_hash})"
                        )
                        xbmc.executebuiltin(intent_url)
                        return
                except Exception:
                    pass
                li = xbmcgui.ListItem(label=title, path=play_url)
                li.setInfo("video", {"title": title, "mediatype": "video"})
                li.setProperty("IsPlayable", "true")
                xbmc.Player().play(play_url, li)
                return

            if play_url.startswith("http"):
                if engine == "AceWeb":
                    port = Config.acestream_engine_port()
                    api_url = f"http://127.0.0.1:{port}/ace/getstream?id={ace_hash}&format=json"
                    playback_url = None
                    stat_url = None
                    command_url = None
                    try:
                        import urllib.request
                        import json
                        req = urllib.request.Request(api_url, headers={"User-Agent": "Kodi/Stremio"})
                        with urllib.request.urlopen(req, timeout=6) as response:
                            if response.status == 200:
                                data = json.loads(response.read().decode("utf-8"))
                                err = data.get("error")
                                if err:
                                    log(f"AceStream engine error: {err}", level="error")
                                    ui.show_notification(f"AceStream: {err}")
                                    return
                                resp_obj = data.get("response") or {}
                                playback_url = resp_obj.get("playback_url")
                                stat_url = resp_obj.get("stat_url")
                                command_url = resp_obj.get("command_url")
                    except Exception as ex:
                        log(f"AceStream JSON endpoint failed ({ex}), falling back to direct URL", level="warning")

                    # Monitor prebuffering so Kodi does not connect before stream is ready
                    if stat_url and playback_url:
                        dp = xbmcgui.DialogProgress()
                        dp.create("AceStream P2P", f"Conectando: {title[:28]}...")
                        import time
                        start_t = time.time()
                        ready = False
                        while not dp.iscanceled() and (time.time() - start_t) < 45:
                            try:
                                sreq = urllib.request.Request(stat_url, headers={"User-Agent": "Kodi/Stremio"})
                                with urllib.request.urlopen(sreq, timeout=3) as sresp:
                                    sdata = json.loads(sresp.read().decode("utf-8")).get("response", {})
                                st = sdata.get("status")
                                prog = int(sdata.get("progress", 0) or 0)
                                peers = sdata.get("peers", 0)
                                spd = sdata.get("speed_down", 0)

                                if st == "dl":
                                    ready = True
                                    break
                                elif st == "prebuf":
                                    dp.update(prog, f"Almacenando búfer P2P: {prog}%", f"Peers conectados: {peers}  |  Descarga: {spd} KB/s")
                                elif st == "check":
                                    dp.update(prog, "Verificando fragmentos de vídeo...", f"Peers conectados: {peers}")
                                else:
                                    dp.update(prog, f"Estado: {st}...", f"Peers conectados: {peers}  |  Descarga: {spd} KB/s")
                            except Exception as ex:
                                log(f"AceStream stat error: {ex}", level="warning")
                            time.sleep(0.3)

                        is_canceled = dp.iscanceled()
                        dp.close()

                        if is_canceled:
                            log("AceStream playback canceled by user", level="info")
                            if command_url:
                                try:
                                    urllib.request.urlopen(f"{command_url}?method=stop", timeout=2)
                                except Exception:
                                    pass
                            return

                        if not ready:
                            ui.show_notification("Tiempo agotado: pocos peers en la red.")
                            log("AceStream prebuffering timed out", level="warning")
                            return

                    target_url = playback_url or play_url
                    log(f"AceStream playing target URL: {target_url}", level="info")

                    li = xbmcgui.ListItem(label=title, path=target_url)
                    li.setInfo("video", {"title": title, "mediatype": "video"})
                    li.setMimeType("video/mp2t")
                    li.setContentLookup(False)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(target_url, li)
                else:
                    li = xbmcgui.ListItem(label=title, path=play_url)
                    li.setInfo("video", {"title": title, "mediatype": "video"})
                    li.setMimeType("video/mp2t")
                    li.setContentLookup(False)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(play_url, li)
            else:
                ui.show_notification("Motor AceStream no reconocido.")
        except Exception as e:
            log(f"AceStream play error: {e}", level="error")
            ui.show_notification(f"Error: {str(e)[:60]}")

    def _acestream_play(self):
        """Play an AceStream channel by hash."""
        try:
            ace_hash = self.params.get("ace_hash", "")
            title = self.params.get("title", "AceStream")

            if not ace_hash:
                ui.show_notification("Hash no valido.")
                return

            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            xbmc.sleep(200)

            self._play_acestream_hash(ace_hash, title)
        except Exception as e:
            log(f"AceStream play error: {e}", level="error")
            ui.show_notification(f"Error: {str(e)[:60]}")

    def _acestream_manual(self):
        """Manually enter an AceStream hash or URL."""
        try:
            text = ui.show_input("Pegar hash AceStream o acestream://")
            if not text:
                return

            text = text.strip().strip('"\'')
            import re

            match = re.search(r'([a-fA-F0-9]{40})', text)
            if not match:
                ui.show_notification("Formato no valido. Usa un hash de 40 chars o acestream://")
                return

            ace_hash = match.group(1).lower()
            self._play_acestream_hash(ace_hash, "AceStream Manual")

        except Exception as e:
            log(f"AceStream manual error: {e}", level="error")
            ui.show_notification(f"Error: {str(e)[:60]}")

    def _acestream_refresh(self):
        """Force refresh AceStream channel list."""
        try:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            xbmc.sleep(200)

            from resources.lib.acestream import AceStreamClient
            ace = AceStreamClient()

            # Clear cache
            self.cache.delete("acestream:channels")
            self.cache.delete_prefix("acestream:health:")

            ui.show_notification("Descargando lista actualizada...", time=3000)

            channels = ace.fetch_channels(force_refresh=True)
            if channels:
                ui.show_notification(f"Cargados {len(channels)} canales!", time=3000)
            else:
                ui.show_notification("No se pudieron cargar canales.", time=3000)

            # Refresh the container
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")

        except Exception as e:
            log(f"AceStream refresh error: {e}", level="error")
            ui.show_notification(f"Error: {str(e)[:60]}")

    @staticmethod
    def _is_vpn_supported():
        import os, shutil
        return shutil.which("connmanctl") is not None and os.path.exists("/storage/.config/wireguard")

    @staticmethod
    def _is_vpn_connected():
        import subprocess
        try:
            res = subprocess.run(["ip", "link", "show", "wg0"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1)
            return res.returncode == 0
        except Exception:
            return False

    def _vpn_toggle(self):
        if not self._is_vpn_supported():
            ui.show_notification("VPN no disponible en este dispositivo.")
            return

        import subprocess
        import os

        vpn_on = self._is_vpn_connected()
        if vpn_on:
            confirmed = ui.show_yesno(
                "Surfshark VPN",
                "¿Deseas DESCONECTAR la VPN de Surfshark?\n\n(Se usará la conexión directa de tu operadora)"
            )
            if confirmed:
                ui.show_notification("Desconectando VPN...", time=2000)
                try:
                    with open("/storage/.config/vpn_manual_off", "w") as f:
                        f.write("1\n")
                    subprocess.run(["connmanctl", "disconnect", "vpn_89_46_223_185"], timeout=5)
                    ui.show_notification("VPN Desconectada (Directo)", time=3000)
                except Exception as e:
                    log(f"Error disconnecting VPN: {e}", level="error")
                    ui.show_notification(f"Error: {e}")
        else:
            confirmed = ui.show_yesno(
                "Surfshark VPN",
                "¿Deseas ACTIVAR la VPN de Surfshark?\n\n(Conectando a servidor de Ámsterdam, Países Bajos)"
            )
            if confirmed:
                try:
                    if os.path.exists("/storage/.config/vpn_manual_off"):
                        try:
                            os.remove("/storage/.config/vpn_manual_off")
                        except Exception:
                            pass
                    ui.show_notification("Conectando a Surfshark...", time=2500)
                    subprocess.run(["connmanctl", "connect", "vpn_89_46_223_185"], timeout=8)
                    xbmc.sleep(1000)
                    if self._is_vpn_connected():
                        ui.show_notification("¡VPN Conectada a Países Bajos!", time=3000)
                    else:
                        ui.show_notification("No se pudo conectar a la VPN", time=3000)
                except Exception as e:
                    log(f"Error connecting VPN: {e}", level="error")
                    ui.show_notification(f"Error: {e}")

        xbmc.sleep(500)
        xbmc.executebuiltin("Container.Refresh")

    # ══════════════════════════════════════════════════════
    #  UTILITIES
    # ══════════════════════════════════════════════════════
    def _render_item_list(self, items, default_media_type="movie"):
        if Config.rt_enabled() and items:
            try:
                self.rt.enrich_items(items)
            except Exception as e:
                log(f"RT enrich error: {e}", level="debug")

        for item in items:
            imdb_id = item.get("imdb_id") or item.get("id", "")
            tmdb_id = item.get("tmdb_id", "")
            title = item.get("name", "Unknown")
            original_title = item.get("original_title", title)
            year = str(item.get("releaseInfo", item.get("year", "")))
            poster = item.get("poster", "")
            plot = item.get("description", "")

            item_type = item.get("type") or default_media_type
            is_series = item_type in ("series", "tv", "show")
            media_type = "series" if is_series else "movie"

            rating = item.get("imdbRating", "")
            rating_tag = ""
            if rating:
                try:
                    r = float(rating)
                    if r >= 7.5:
                        rating_tag = f" [COLOR gold]★{rating}[/COLOR]"
                    elif r >= 5.0:
                        rating_tag = f" [COLOR yellow]★{rating}[/COLOR]"
                    else:
                        rating_tag = f" [COLOR grey]★{rating}[/COLOR]"
                except (ValueError, TypeError):
                    pass

            # Rotten Tomatoes tag
            rt_score = item.get("rt_score", "")
            rt_tag = self.rt.format_rt_tag(rt_score) if rt_score else ""

            if original_title and original_title.strip().lower() != title.strip().lower():
                display_title = f"{original_title} [COLOR grey]({title})[/COLOR]"
            else:
                display_title = title

            label = f"{display_title} ({year}){rating_tag}{rt_tag}" if year else f"{display_title}{rating_tag}{rt_tag}"
            if is_series:
                click = "tmdb_seasons" if tmdb_id else "seasons"
            else:
                click = "streams"

            fav_id = imdb_id if imdb_id else f"tmdb:{tmdb_id}"
            ctx = self._make_fav_context(fav_id, media_type, title, year, poster)

            # Build enriched plot / description
            meta_header = []
            if rating:
                meta_header.append(f"★ {rating}/10")
            if rt_score:
                meta_header.append(f"🍅 Rotten Tomatoes: {rt_score}%")
            if item.get("metascore"):
                meta_header.append(f"Metacritic: {item.get('metascore')}")

            header_str = " | ".join(meta_header)
            extra_lines = []
            if header_str:
                extra_lines.append(header_str)
            if item.get("awards"):
                extra_lines.append(f"🏆 {item.get('awards')}")

            if extra_lines and plot:
                plot = "\n".join(extra_lines) + "\n\n" + plot
            elif extra_lines:
                plot = "\n".join(extra_lines)

            kwargs = {
                "handle": self.handle, "label": label, "action": click,
                "base_url": self.base_url, "poster": poster,
                "fanart": item.get("background", item.get("fanart", "")),
                "plot": plot, "year": year, "imdb_id": imdb_id,
                "media_type": media_type, "context_menu": ctx, "title": title,
                "original_title": original_title, "rating": rating
            }
            if tmdb_id:
                kwargs["tmdb_id"] = tmdb_id

            ui.add_directory_item(**kwargs)

    def _make_fav_context(self, imdb_id, media_type, title, year, poster, tmdb_id=""):
        fav_label = "Quitar de Favoritos" if self.cache.is_favorite(imdb_id) \
            else "Agregar a Favoritos"
        fav_url = ui.build_url(
            self.base_url, action="toggle_favorite",
            imdb_id=imdb_id, media_type=media_type,
            title=title, year=year, poster=poster,
        )
        ctx = [(fav_label, f"RunPlugin({fav_url})")]

        if media_type == "movie":
            sub_url = ui.build_url(
                self.base_url, action="search_subtitles",
                imdb_id=imdb_id, tmdb_id=tmdb_id,
                media_type=media_type, title=title,
            )
            ctx.append(("💬 Buscar Subtítulos (OpenSubtitles)", f"RunPlugin({sub_url})"))

        if Config.trakt_enabled():
            trakt_url = ui.build_url(
                self.base_url, action="trakt_add",
                imdb_id=imdb_id, media_type=media_type,
            )
            ctx.append(("Agregar a Trakt Watchlist", f"RunPlugin({trakt_url})"))

        return ctx

    def _clear_cache(self):
        self.cache.clear_all()
        ui.show_notification("Cache limpiada!")
        try:
            import xbmcplugin
            xbmcplugin.endOfDirectory(self.handle, succeeded=True)
        except Exception:
            pass

    def _clear_history(self):
        self.cache.clear_history()
        ui.show_notification("Historial borrado!")
        xbmc.executebuiltin("Container.Refresh")

    def _settings(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        xbmc.sleep(100)
        xbmcaddon.Addon().openSettings()
