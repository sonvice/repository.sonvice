# -*- coding: utf-8 -*-
import sys
import os
import subprocess
import urllib.request
import json
import xbmc
import xbmcgui

CONNMANCTL = "/usr/bin/connmanctl"
FLAG_MANUAL_OFF = "/storage/.config/vpn_manual_off"

def get_connection_info():
    """Returns a dict with ip, country, city, org, and summary string."""
    info = {
        "ip": "Desconocida",
        "country": "",
        "city": "",
        "org": "Desconocido",
        "summary": "Desconocida"
    }
    try:
        req = urllib.request.Request("https://ipinfo.io/json", headers={"User-Agent": "curl/7.68.0"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            info["ip"] = data.get("ip", "?")
            info["country"] = data.get("country", "")
            info["city"] = data.get("city", "")
            info["org"] = data.get("org", "")
            loc = f" ({info['country']})" if info['country'] else ""
            info["summary"] = f"{info['ip']}{loc} - {info['org'][:25]}"
            return info
    except Exception:
        try:
            req = urllib.request.Request("https://api.ipify.org", headers={"User-Agent": "curl/7.68.0"})
            with urllib.request.urlopen(req, timeout=2) as resp:
                info["ip"] = resp.read().decode("utf-8").strip()
                info["summary"] = info["ip"]
                return info
        except Exception:
            return info

def is_vpn_interface_active():
    """Checks if default route uses wg0 or if wg0 is active."""
    try:
        out = subprocess.check_output(["ip", "route"], timeout=2).decode("utf-8")
        for line in out.splitlines():
            if line.startswith("default") and "wg0" in line:
                return True
    except Exception:
        pass
    return False

def get_vpn_services():
    services = []
    try:
        out = subprocess.check_output([CONNMANCTL, "services"], timeout=3).decode("utf-8")
        for line in out.splitlines():
            if "vpn_" in line:
                is_active = "* R" in line
                parts = line.strip().split()
                service_id = parts[-1]
                name = " ".join([p for p in parts[:-1] if p not in ("*", "R", "A", "O")]).strip()
                services.append({
                    "name": name,
                    "id": service_id,
                    "active": is_active
                })
    except Exception as e:
        xbmcgui.Dialog().notification("Error VPN", str(e), xbmcgui.NOTIFICATION_ERROR, 3000)
    return services

def main():
    p_dialog = xbmcgui.DialogProgressBG()
    p_dialog.create("Comprobando conexión...", "Obteniendo estado de red y VPN...")

    info = get_connection_info()
    vpn_active = is_vpn_interface_active()
    services = get_vpn_services()
    p_dialog.close()

    active_service = next((s for s in services if s["active"]), None)

    options = []
    actions = []

    # 1. Status header (Huge, Colorful & Clear)
    if vpn_active or active_service:
        srv_name = active_service['name'] if active_service else "Surfshark (WireGuard)"
        options.append(f"[COLOR lime][B]🛡️ ESTADO: VPN CONECTADA[/B][/COLOR] ({srv_name})")
        actions.append(("none", None, None))
        options.append(f"[COLOR yellow]📍 IP Pública: {info['summary']}[/COLOR]")
        actions.append(("none", None, None))
        options.append("[COLOR red][B]⏹ DESCONECTAR VPN (Activar Fibra Directa)[/B][/COLOR]")
        actions.append(("disconnect", active_service['id'] if active_service else "vpn_89_46_223_185", srv_name))
    else:
        options.append("[COLOR red][B]⚡ ESTADO: VPN DESCONECTADA (Fibra Directa)[/B][/COLOR]")
        actions.append(("none", None, None))
        options.append(f"[COLOR cyan]📍 IP Pública: {info['summary']}[/COLOR]")
        actions.append(("none", None, None))
        # Find default Surfshark service
        ss = next((s for s in services if "89_46_223" in s["id"] or "Surfshark" in s["name"]), None)
        ss_id = ss['id'] if ss else "vpn_89_46_223_185"
        ss_name = ss['name'] if ss else "Surfshark Netherlands"
        options.append(f"[COLOR lime][B]▶ CONECTAR {ss_name}[/B][/COLOR]")
        actions.append(("connect", ss_id, ss_name))

    # 2. Alternative VPN connections
    for s in services:
        if not s["active"]:
            options.append(f"  ▶ Conectar a {s['name']}")
            actions.append(("connect", s['id'], s['name']))

    # 3. Connection detail dialog
    options.append("[COLOR skyblue]🔍 Ver reporte completo de IP y Proveedor[/COLOR]")
    actions.append(("check_ip", None, None))

    status_tag = "🛡️ VPN ACTIVA" if (vpn_active or active_service) else "⚡ FIBRA DIRECTA"
    choice = xbmcgui.Dialog().select(f"Control VPN CoreELEC — [{status_tag}]", options)

    if choice < 0:
        return

    action, s_id, s_name = actions[choice]
    if action == "none":
        return

    if action == "disconnect":
        progress = xbmcgui.DialogProgress()
        progress.create("Control VPN", "Desconectando VPN y restaurando fibra directa...")
        try:
            with open(FLAG_MANUAL_OFF, "w") as f:
                f.write("1\n")
        except Exception:
            pass
        subprocess.run([CONNMANCTL, "disconnect", s_id], timeout=5)
        # Ensure default gateway is back on eth0
        try:
            subprocess.run(["ip", "route", "add", "default", "via", "192.168.1.1", "dev", "eth0"], timeout=2)
        except Exception:
            pass
        xbmc.sleep(1500)
        progress.close()
        new_info = get_connection_info()
        xbmcgui.Dialog().ok(
            "VPN Desconectada ⚡",
            f"La VPN se ha desactivado correctamente.\n\n"
            f"Ahora navegas directamente con tu operadora:\n"
            f"• IP Pública: {new_info['ip']}\n"
            f"• Operador: {new_info['org']}\n"
            f"• Ubicación: {new_info['city']}, {new_info['country']}\n\n"
            f"(El reconector automático permanecerá desactivado)."
        )

    elif action == "connect":
        progress = xbmcgui.DialogProgress()
        progress.create("Control VPN", f"Conectando a {s_name}...")
        try:
            if os.path.exists(FLAG_MANUAL_OFF):
                os.remove(FLAG_MANUAL_OFF)
        except Exception:
            pass
        if active_service and active_service['id'] != s_id:
            subprocess.run([CONNMANCTL, "disconnect", active_service['id']], timeout=5)
            xbmc.sleep(500)
        subprocess.run([CONNMANCTL, "connect", s_id], timeout=8)
        xbmc.sleep(2000)
        progress.close()
        new_info = get_connection_info()
        xbmcgui.Dialog().ok(
            "VPN Conectada 🛡️",
            f"Tu conexión ahora está protegida por la VPN:\n\n"
            f"• Servidor: {s_name}\n"
            f"• IP Pública VPN: {new_info['ip']}\n"
            f"• Proveedor: {new_info['org']}\n"
            f"• Ubicación: {new_info['city']}, {new_info['country']}"
        )

    elif action == "check_ip":
        state_str = "🛡️ VPN CONECTADA" if (vpn_active or active_service) else "⚡ FIBRA DIRECTA (Sin VPN)"
        xbmcgui.Dialog().ok(
            "Información de Red y VPN",
            f"Estado: {state_str}\n\n"
            f"• IP Pública: {info['ip']}\n"
            f"• Proveedor / ISP: {info['org']}\n"
            f"• Ciudad: {info['city']}\n"
            f"• País: {info['country']}"
        )

if __name__ == "__main__":
    main()
