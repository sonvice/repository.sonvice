# -*- coding: utf-8 -*-
import sys
import subprocess
import urllib.request
import json
import xbmc
import xbmcgui

CONNMANCTL = "/usr/bin/connmanctl"

def get_public_ip():
    try:
        req = urllib.request.Request("https://ipinfo.io/json", headers={"User-Agent": "curl/7.68.0"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ip = data.get("ip", "?")
            country = data.get("country", "?")
            org = data.get("org", "")
            return f"{ip} ({country}) - {org[:20]}"
    except Exception:
        try:
            req = urllib.request.Request("https://api.ipify.org", headers={"User-Agent": "curl/7.68.0"})
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.read().decode("utf-8").strip()
        except Exception:
            return "Desconocida"

def get_vpn_services():
    services = []
    try:
        out = subprocess.check_output([CONNMANCTL, "services"], timeout=3).decode("utf-8")
        for line in out.splitlines():
            if "vpn_" in line:
                is_active = "* R" in line
                parts = line.strip().split()
                service_id = parts[-1]
                name = " ".join([p for p in parts[:-1] if p not in ("*", "R", "A", "O")]).strip()
                services.append({
                    "name": name,
                    "id": service_id,
                    "active": is_active
                })
    except Exception as e:
        xbmcgui.Dialog().notification("Error VPN", str(e), xbmcgui.NOTIFICATION_ERROR, 3000)
    return services

def main():
    services = get_vpn_services()
    if not services:
        xbmcgui.Dialog().ok("Control VPN", "No se encontraron conexiones VPN configuradas en CoreELEC.")
        return

    active_vpn = next((s for s in services if s["active"]), None)

    options = []
    actions = []

    if active_vpn:
        options.append(f"[COLOR red]● Desconectar VPN[/COLOR]  ({active_vpn['name']})")
        actions.append(("disconnect", active_vpn['id'], active_vpn['name']))
    else:
        options.append("[COLOR grey]○ Estado: VPN Desconectada (Fibra directa)[/COLOR]")
        actions.append(("none", None, None))

    for s in services:
        if s["active"]:
            options.append(f"[COLOR lime]✔ Conectado a {s['name']}[/COLOR]")
            actions.append(("none", None, None))
        else:
            options.append(f"[COLOR yellow]▶ Conectar a {s['name']}[/COLOR]")
            actions.append(("connect", s['id'], s['name']))

    options.append("[COLOR skyblue]ℹ Consultar IP pública actual[/COLOR]")
    actions.append(("check_ip", None, None))

    status_str = f"Activo: {active_vpn['name']}" if active_vpn else "Desconectado"
    choice = xbmcgui.Dialog().select(f"Control VPN — {status_str}", options)

    if choice < 0:
        return

    action, s_id, s_name = actions[choice]

    if action == "disconnect":
        subprocess.run([CONNMANCTL, "disconnect", s_id], timeout=5)
        xbmc.sleep(1000)
        ip = get_public_ip()
        xbmcgui.Dialog().notification("VPN Desconectada ⚡", f"Fibra directa: {ip}", xbmcgui.NOTIFICATION_INFO, 4000)

    elif action == "connect":
        if active_vpn and active_vpn['id'] != s_id:
            subprocess.run([CONNMANCTL, "disconnect", active_vpn['id']], timeout=5)
            xbmc.sleep(500)
        subprocess.run([CONNMANCTL, "connect", s_id], timeout=8)
        xbmc.sleep(1000)
        ip = get_public_ip()
        xbmcgui.Dialog().notification("VPN Conectada 🛡️", f"{s_name} | {ip}", xbmcgui.NOTIFICATION_INFO, 4000)

    elif action == "check_ip":
        ip = get_public_ip()
        state = f"Conectado a {active_vpn['name']}" if active_vpn else "Fibra directa (Sin VPN)"
        msg = f"Estado: {state}\nIP Pública: {ip}"
        xbmcgui.Dialog().ok("Información de Conexión", msg)

if __name__ == "__main__":
    main()
