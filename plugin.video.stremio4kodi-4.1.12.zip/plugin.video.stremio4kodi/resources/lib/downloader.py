# -*- coding: utf-8 -*-
"""
Unified Stream Downloader for Stremio4Kodi.
Downloads live playing streams (TorrServer, Elementum, Debrid, Direct HTTP)
directly into the user-specified directory as clean, playable .mkv / .mp4 video files.
"""
import os
import re
import socket
import threading
import urllib.parse
import urllib.request

from resources.lib.config import Config
from resources.lib.logger import log

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

_active_downloads = set()
_lock = threading.Lock()


def get_clean_video_filename(title, stream_url="", media_type=None, season=None, episode=None, show_title=None):
    """
    Constructs a clean, standard media filename like:
    'Modern Family S01E01.mkv' or 'Oppenheimer (2023).mkv'
    """
    ext = ".mkv"  # Default video container

    # Check if stream URL has extension
    url_path = urllib.parse.urlparse(stream_url).path if stream_url else ""
    raw_name = url_path.split("/")[-1] if url_path else ""
    for candidate_ext in (".mkv", ".mp4", ".avi", ".ts", ".webm", ".mov", ".m4v"):
        if raw_name.lower().endswith(candidate_ext):
            ext = candidate_ext
            break
        elif title and title.lower().endswith(candidate_ext):
            ext = candidate_ext
            break

    # Construct base title
    if media_type == "series" and season is not None and episode is not None:
        try:
            s_num = int(season)
            e_num = int(episode)
            show = (show_title or "").strip()
            if not show and title:
                show = re.sub(r"\s+S\d+E\d+.*$", "", title, flags=re.I).strip()
            if not show:
                show = "Series"
            base_name = f"{show} S{s_num:02d}E{e_num:02d}"
        except (ValueError, TypeError):
            base_name = title or "Video"
    else:
        base_name = title or "Video"

    # Remove invalid characters for filesystem
    base_name = re.sub(r'[/\\?%*:|"<>]', '.', base_name)
    base_name = re.sub(r'\s+', ' ', base_name).strip()
    if base_name.lower().endswith(ext):
        return base_name

    return f"{base_name}{ext}"


def start_playback_download(playable_url, title="video", media_type=None, season=None, episode=None, show_title=None, stream_info=None):
    """
    Main entry point called when any video stream is launched in Kodi.
    If the advanced download option is enabled, streams the content
    in the background directly into a playable video file (.mkv / .mp4).
    """
    if not Config.download_playback_enabled():
        return

    raw_dir = Config.download_playback_path()
    if not raw_dir or not raw_dir.strip():
        log("Download during playback enabled but no download path is configured", level="info")
        return

    if not playable_url or not playable_url.startswith("http"):
        return

    target_dir = raw_dir.strip()
    if xbmcvfs:
        target_dir = xbmcvfs.translatePath(target_dir)

    try:
        os.makedirs(target_dir, exist_ok=True)
    except Exception as e:
        log(f"Cannot create download directory '{target_dir}': {e}", level="warning")
        return

    filename = get_clean_video_filename(
        title=title,
        stream_url=playable_url,
        media_type=media_type,
        season=season,
        episode=episode,
        show_title=show_title,
    )

    final_path = os.path.join(target_dir, filename)
    part_path = os.path.join(target_dir, f"{filename}.part")

    with _lock:
        if final_path in _active_downloads:
            log(f"Download already active for '{filename}', skipping duplicate launch", level="info")
            return
        # If final file exists and is substantial (> 10 MB), consider it done
        if os.path.exists(final_path) and os.path.getsize(final_path) > 10 * 1024 * 1024:
            log(f"File '{filename}' already exists on disk ({os.path.getsize(final_path)} bytes), skipping", level="info")
            return
        _active_downloads.add(final_path)

    log(f"Starting background stream download: '{filename}' -> '{part_path}'", level="info")

    def _worker():
        try:
            if xbmcgui:
                try:
                    xbmcgui.Dialog().notification(
                        "Stremio4Kodi",
                        f"Descargando en segundo plano: {filename[:28]}",
                        xbmcgui.NOTIFICATION_INFO,
                        3500
                    )
                except Exception:
                    pass

            # Check if partial download exists to resume
            existing_bytes = 0
            open_mode = "wb"
            if os.path.exists(part_path):
                existing_bytes = os.path.getsize(part_path)
                if existing_bytes > 0:
                    open_mode = "ab"

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
                "Connection": "keep-alive",
            }
            if existing_bytes > 0:
                headers["Range"] = f"bytes={existing_bytes}-"

            # Connect with generous timeout (gives TorrServer time to buffer swarm)
            req = urllib.request.Request(playable_url, headers=headers)
            try:
                resp = urllib.request.urlopen(req, timeout=45)
            except urllib.error.HTTPError as he:
                if he.code == 416:  # Range Not Satisfiable (already finished or invalid range)
                    headers.pop("Range", None)
                    open_mode = "wb"
                    existing_bytes = 0
                    req = urllib.request.Request(playable_url, headers=headers)
                    resp = urllib.request.urlopen(req, timeout=45)
                else:
                    raise

            # Detect real container format from HTTP headers or first bytes
            detected_ext = None
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if "matroska" in ctype or "mkv" in ctype:
                detected_ext = ".mkv"
            elif "mp4" in ctype:
                detected_ext = ".mp4"
            elif "avi" in ctype:
                detected_ext = ".avi"

            with open(part_path, open_mode) as out_f:
                chunk_size = 512 * 1024  # 512 KB chunks
                first_chunk = True

                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break

                    # If this is the start of the file, verify magic bytes
                    if first_chunk and existing_bytes == 0 and len(chunk) >= 8:
                        first_chunk = False
                        if chunk[:4] == b"\x1a\x45\xdf\xa3":
                            detected_ext = ".mkv"
                        elif len(chunk) >= 8 and chunk[4:8] == b"ftyp":
                            detected_ext = ".mp4"
                        elif chunk[:4] == b"RIFF":
                            detected_ext = ".avi"

                    out_f.write(chunk)

            # Check if extension needs to be adjusted based on detected container
            current_final_path = final_path
            if detected_ext and not filename.lower().endswith(detected_ext):
                base_without_ext = os.path.splitext(filename)[0]
                new_filename = f"{base_without_ext}{detected_ext}"
                current_final_path = os.path.join(target_dir, new_filename)

            # Finalize: rename .part to destination video file
            if os.path.exists(part_path):
                file_size = os.path.getsize(part_path)
                if file_size > 1024 * 1024:  # At least 1 MB
                    if os.path.exists(current_final_path):
                        try:
                            os.remove(current_final_path)
                        except Exception:
                            pass
                    os.rename(part_path, current_final_path)
                    log(f"Stream download finished successfully: '{current_final_path}' ({file_size} bytes)", level="info")

                    if xbmcgui:
                        try:
                            clean_display = os.path.basename(current_final_path)
                            xbmcgui.Dialog().notification(
                                "Stremio4Kodi",
                                f"Descarga completa: {clean_display[:30]}",
                                xbmcgui.NOTIFICATION_INFO,
                                5000
                            )
                        except Exception:
                            pass
                else:
                    log(f"Downloaded part file was too small ({file_size} bytes), removing corrupted part", level="warning")
                    try:
                        os.remove(part_path)
                    except Exception:
                        pass

        except Exception as e:
            log(f"Stream download error for '{filename}': {e}", level="warning")
            # If user configured to not keep partial files, delete .part
            if not Config.download_playback_keep():
                try:
                    if os.path.exists(part_path):
                        os.remove(part_path)
                except Exception:
                    pass
        finally:
            with _lock:
                _active_downloads.discard(final_path)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()


# Backward compatibility
start_direct_download = start_playback_download
