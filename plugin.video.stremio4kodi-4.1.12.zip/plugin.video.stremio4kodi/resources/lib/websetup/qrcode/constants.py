from __future__ import annotations  # MegaNexus: Kodi on Windows embeds Python 3.8
# QR error correct levels
ERROR_CORRECT_L = 1
ERROR_CORRECT_M = 0
ERROR_CORRECT_Q = 3
ERROR_CORRECT_H = 2
